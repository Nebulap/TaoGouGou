import {createRouter, createWebHistory} from "vue-router";

const routes = [
    {
        path:"/",
        name:"home",
        component:()=>import('../views/home/index.vue'),
        meta:{
            label:"首页"
        }
    },
    {
        path:"/shop",
        name:"shop",
        component:()=>import('../views/shop/index.vue'),
        meta:{
            label:"购物"
        }
    },
    {
        path:"/me",
        name:"me",
        component:()=>import('../views/me/index.vue'),
        meta:{
            label:"我的订单"
        }
    }
]


const router = createRouter({
    history: createWebHistory(),
    routes
})

export default router;


