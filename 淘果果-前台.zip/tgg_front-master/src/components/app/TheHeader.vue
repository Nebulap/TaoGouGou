<script setup>

import {computed, h, nextTick, onBeforeUnmount, onMounted, ref} from "vue";
import {useRouter} from "vue-router";
import img from '../../assets/slide-1.jpg'
import {useUserStore} from "../../store/useUserStore.js";
import TheLoginFrom from "./TheLoginFrom.vue";
import TheCart from "./TheCart.vue";
import {useOrderStore} from "../../store/useOrderStore.js";

defineProps({
  isHome: {
    type: Boolean
  }
})

const options = computed(() => [
  {
    label: '用户资料',
    key: 'profile',
    icon: renderIcon("i-ri:contacts-fill")
  },
  {
    label: '登录',
    key: 'login',
    show: !userStore.state.isLogin,
    icon: renderIcon("i-ri:expand-right-fill")
  },
  {
    label: '退出登录',
    key: 'logout',
    show: userStore.state.isLogin,
    icon: renderIcon("i-ri:expand-left-fill")
  }
])

const showNav = ref(false)
const router = useRouter()
const userStore = useUserStore()
const orderStore = useOrderStore()

const navList = computed(() => {
  return router.options.routes.map(item => ({
    path: item.path,
    label: item.meta['label']
  }))
})

function handleSelect(key) {
  switch (key) {
    case 'login':
      loginHandle()
      break;
    case 'logout':
      logoutHandle()
      break;
    case 'profile':
      ProfileHandle()
  }
}

function ProfileHandle() {
  if (!userStore.state.isLogin) {
    $message.info("请先登录!")
    return
  }
}

function loginHandle() {
  userStore.state.showFrom = true
}

function logoutHandle() {
  userStore.logout()
}


function renderIcon(icon) {
  return () => h("span", {class: icon})
}

function scrollHandler() {
  const top = window.scrollY
  orderStore.closeCard()
  showNav.value = top >= 255
}

onMounted(() => {
  window.addEventListener('scroll', scrollHandler)
})

onBeforeUnmount(() => {
  window.removeEventListener("scroll", scrollHandler)
})

</script>

<template>
  <TheLoginFrom/>
  <the-cart class="pos-fixed top-28 right-100 z-3" />
  <n-space v-show="showNav" align="center" justify="center" class="z-36 w-full bg-[rgb(98,159,200)] pos-fixed top-0 animate__animated animate__fadeInDown"
           :class="{animate__fadeInDown:showNav}">
    <div v-for="nav in navList" :class="{'!text-[rgb(239,225,94)]':$route.path === nav.path}" @click="$router.push(nav.path)"
         class="py-5 px-3 font-bold cursor-pointer transition-all text-white text-4 hover:text-[rgb(239,225,94)]">{{ nav.label }}
    </div>
  </n-space>
  <div class="px-[20%] flex flex-col" :class="{homeHeader:isHome}">
    <!--    头部-->
    <n-space class="py-10" justify="space-between" align="center">
      <!--    联系方式-->
      <n-space vertical>
        <div class="text-white" :class="{'!text-[#3C3C3CFF]':!isHome}">
          <span class="font-bold">联系我们</span>
          : 17883369582
          <div>
            2900221581@qq.com
          </div>
        </div>
      </n-space>
      <div class="pos-relative">
        <div class="font-bold text-3xl" style="font-family: 仿宋,sans-serif">
          <span class="text-yellow-400">淘</span>
          <span class="text-[rgb(139,192,60)]">果果</span>
        </div>
        <img src="../../assets/logo.svg" class="w-[32px] h-[32px] pos-absolute -top-5 -right-5" alt="">
      </div>
      <n-space align="center">
        <div :class="{'!text-[#3C3C3CFF]':!isHome}" class="i-ri:search-line text-3xl font-bold text-white transition-all-500 hover:text-[rgb(246,230,94)] cursor-pointer"></div>
        <div :class="{'!text-[#3C3C3CFF]':!isHome}"
             @click="orderStore.switchShow"
             class="i-ri:shopping-cart-2-line font-bold text-3xl text-white transition-all-500 hover:text-[rgb(246,230,94)] cursor-pointer"></div>
        <n-dropdown :options="options" @select="handleSelect" animated>
          <n-avatar circle class="mt-2"></n-avatar>
        </n-dropdown>
      </n-space>
    </n-space>
    <!--    导航栏-->
    <n-space justify="center" align="center"
             style="border-top: 1px solid rgb(255,255,255,0.2);border-bottom: 1px solid rgb(255,255,255,0.2)"
             :style="{borderTop: !isHome? '1px solid rgb(0,0,0,0.2)' : '1px solid rgb(255,255,255,0.2)', borderBottom:  !isHome? '' : ' 1px solid rgb(255,255,255,0.2)'}"
    >
      <div v-for="nav in navList" :class="{'!text-[rgb(239,225,94)]':$route.path === nav.path,'!text-[#3C3C3CFF]':!isHome}" @click="$router.push(nav.path)"
           class="py-5 px-3 font-bold cursor-pointer transition-all text-white text-4 hover:text-[rgb(239,225,94)]">{{ nav.label }}
      </div>
    </n-space>

    <!--    额外内容-->
    <n-space vertical justify="center" class="my-30 mt-40" v-if="isHome">
      <div class="text-6xl text-white w-[400px] line-height-tight mb-4 animate__animated animate__fadeInLeft ">
        更健康生活的美味方式
      </div>
      <div class="text-2xl text-white w-[400px] line-height-tight mb-9 animate__animated animate__fadeInLeft ">
        我们的有机食品含有您健康所需的所有元素和维生素。
      </div>
      <button
          class="shadow-xl p-4 px-12 bg-transparent rounded text-white text-2xl font-bold  transition-all-500 cursor-pointer hover:bg-[rgb(60,195,193)] hover:!border-transparent animate__animated animate__fadeInLeft "
          style="border: 2px solid white">
        立即选购
      </button>
    </n-space>
  </div>
</template>

<style scoped>
.homeHeader {
  background-image: url('../../assets/slide-1.jpg')
}

.linkActive {
  color: rgb(239, 225, 94);
}
</style>
