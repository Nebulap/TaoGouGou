<script setup>

</script>

<template>
<n-space vertical class="bg-[rgb(56,61,63)] py-10">
  <div class="text-center text-gray-400">Copyright © 2024.ForestAndForest All rights reserved.</div>
</n-space>
</template>

<style scoped>

</style>
