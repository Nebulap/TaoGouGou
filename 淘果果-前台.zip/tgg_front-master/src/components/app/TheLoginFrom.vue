<script setup>


import {useUserStore} from "../../store/useUserStore.js";
import {ref, toRefs} from "vue";
import {storeToRefs} from "pinia";

const userStore = useUserStore()
const loginForm = ref({
  username: "",
  password: ""
})

const registerForm = ref({
  username: "",
  password: "",
  rePassword: ""
})


async function loginHandle() {
  const isLogin = await userStore.login(loginForm.value)
  if (isLogin) {
    userStore.state.showFrom = false
    loginForm.value = {
      username: "",
      password: ""
    }
  }
}

async function registerHandle() {
  const isLogin = await userStore.register(registerForm.value)

  if (isLogin) {
    userStore.state.showFrom = false
    registerForm.value = {
      username: "",
      password: "",
      rePassword: ""
    }
  }
}

</script>

<template>
  <n-modal v-model:show="userStore.state.showFrom">
    <n-card class="w-[600px]">
      <n-tabs
          class="card-tabs"
          default-value="signin"
          size="large"
          animated
          pane-wrapper-style="margin: 0 -4px"
          pane-style="padding-left: 4px; padding-right: 4px; box-sizing: border-box;"
      >
        <n-tab-pane name="signin" tab="登录">
          <n-form>
            <n-form-item-row label="用户名">
              <n-input v-model:value="loginForm.username" placeholder="请输入用户名"/>
            </n-form-item-row>
            <n-form-item-row label="密码">
              <n-input v-model:value="loginForm.password" placeholder="请输入密码"/>
            </n-form-item-row>
          </n-form>
          <n-button type="primary" block secondary strong @click="loginHandle">
            登录
          </n-button>
        </n-tab-pane>
        <n-tab-pane name="signup" tab="注册">
          <n-form>
            <n-form-item-row label="用户名">
              <n-input v-model:value="registerForm.username" placeholder="请输入用户名"/>
            </n-form-item-row>
            <n-form-item-row label="密码">
              <n-input v-model:value="registerForm.password" placeholder="请输入密码"/>
            </n-form-item-row>
            <n-form-item-row label="重复密码">
              <n-input v-model:value="registerForm.rePassword" placeholder="请输入密码"/>
            </n-form-item-row>
          </n-form>
          <n-button type="primary" block secondary strong @click="registerHandle">
            注册
          </n-button>
        </n-tab-pane>
      </n-tabs>
    </n-card>
  </n-modal>
</template>

<style scoped>

</style>
