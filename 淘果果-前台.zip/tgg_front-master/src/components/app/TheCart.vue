<script setup>
import {useOrderStore} from "../../store/useOrderStore.js";
import {computed, h, ref} from "vue";
import {useUserStore} from "../../store/useUserStore.js";

const orderStore = useOrderStore()
const userStore = useUserStore()
const showCheckout = ref(false)


const deliveryAddress = ref("");


const totalPrice = computed(() => orderStore.state.cartList.reduce((s, c) => s + c.produce['price'] * c['number'], 0).toFixed(2))
const quantity = computed(() => orderStore.state.cartList.reduce((s, c) => s + c['number'], 0))


function onCheckout() {
  if (!userStore.state.isLogin){
    $message.warning("请先登录!")
    return
  }
  if (orderStore.state.cartList.length === 0) {
    $message.info("请选择产品")
  } else {
    showCheckout.value = true
  }
}

async function confirmCheckout() {
  const {userId} = userStore.state
  const products = orderStore.state.cartList.map(item => ({productId: item['produce']['id'], number: item['number']}))
  const data = {
    customerId: userId,
    totalPrice: totalPrice.value,
    products: products,
    quantity: quantity.value,
    totalProfit: orderStore.state.cartList.reduce((s, c) => s + (c['produce']['price'] - c['produce']['purchasePrice']) * c['number'], 0),
    hideProfit: orderStore.state.cartList.reduce((s, c) => s + c['produce']['hideProfit'], 0),
    deliveryAddress: deliveryAddress.value
  }
  const res = (await $http.post("/api/order/add", data)).data
  if (res['code'] === 100) {
    $message.success("提交成功")
    showCheckout.value = false
    orderStore.cleanCart()
  } else {
    $message.warning("提交失败")
  }
}
</script>

<template>
  <div>
    <n-space v-if="orderStore.state.showCard" vertical class="cart-inline p-5 min-w-[400px] bg-white shadow-xl">
      <div class="text-[#242424ff] text-4">购物车: {{ orderStore.state.cartList.length }}件产品</div>
      <div class="text-[#242424ff] text-4">总金额: <span class="text-red-600 text-6">¥ {{ totalPrice }}</span></div>
      <n-divider class="!my-2"/>
      <n-space v-if="orderStore.state.cartList.length >0" vertical class="max-h-[400px] overflow-y-auto">
        <n-space align="center" v-for="data in orderStore.state.cartList">
          <div class="bg-[rgb(245,245,245)] w-[108px] h-[108px] flex justify-center items-center cursor-pointer">
            <img :src="data['produce']['img']" alt="" class="w-[75px] transition-all-300 hover:scale-110">
          </div>
          <n-space vertical justify="center" class="ml-2">
            <div class="text-5">{{ data['produce']['productName'] }}</div>
            <n-space align="center">
              <div class="w-max hover:text-[rgb(60,195,193)] transition-all-300 cursor-pointer" style="border: #c4c4c4 solid 1px;border-radius: 5px"
                   @click="()=>orderStore.decrease(data['produce']['id'])">
                <div class="i-ri:subtract-fill  text-7 m-1"></div>
              </div>
              <div class="text-6">{{ data['number'] }}</div>
              <div class="w-max hover:text-[rgb(60,195,193)] transition-all-300 cursor-pointer" style="border: #c4c4c4 solid 1px;border-radius: 5px"
                   @click="()=>orderStore.increase(data['produce']['id'])">
                <div class="i-ri:add-fill text-7 m-1"></div>
              </div>
              <div class="text-5 font-bold">
                ¥ {{ (data['produce']['price'] * data['number']).toFixed(2) }}
              </div>
            </n-space>
          </n-space>
        </n-space>
      </n-space>
      <div v-else class="text-center text-5 text-[#808080] font-bold">空空如也</div>
      <n-divider class="!my-2"/>
      <div class="grid-cols-2 grid gap-5">
        <div class="button !bg-white !text-black" style="--c-bg:rgb(60,195,193);--c-text:rgb(0,0,0);border: #a7a7a7 solid 2px" @click="orderStore.cleanCart">
          清空购物车
        </div>
        <div class="button " style="--c-bg:rgb(249, 233, 94);--c-text:rgb(0,0,0)" @click="onCheckout">
          结账
        </div>
      </div>
    </n-space>
    <n-modal v-model:show="showCheckout" closable>
      <div class="p-5 min-w-[400px] bg-white shadow-xl rounded-xl">
        <div class="flex items-center mb-4">
          <div class="i-ri:bit-coin-fill text-2xl text-yellow-400"></div>
          <div class="text-5 font-bold">结算</div>
        </div>


        <!-- 展示选择商品 -->
        <div class="mb-4">
          <div class="text-sm font-semibold mb-2">已选产品</div>
          <ul>
            <li type="none" v-for="data in orderStore.state.cartList" :key=" data['produce']['id']" class="mb-2 text-4">
              <div class="flex justify-between items-center">
                <div>{{ data['produce']['productName'] }} * {{ data['number'] }}</div>
                <div><span class="text-red-600">¥ {{ (data['produce']['price'] * data['number']).toFixed(2) }}</span></div>
              </div>
            </li>
          </ul>
        </div>

        <!-- 选择地址 -->
        <div class="mb-4">
          <div class="text-sm font-semibold mb-2">地址</div>
          <n-input v-model:value="deliveryAddress" placeholder="请输入你的地址"/>
        </div>

        <!-- 确认取消按钮 -->
        <div class="flex justify-between items-center space-x-4">
          <span class="text-red-600 text-6 font-bold">¥ {{ totalPrice }}</span>
          <div class="flex gap-4">
            <n-button @click="()=>showCheckout=false">取消</n-button>
            <n-button type="primary" @click="confirmCheckout">确认</n-button>
          </div>
        </div>
      </div>
    </n-modal>
  </div>
</template>

<style scoped>
.button {
  background-color: rgb(60, 195, 193);
  color: white;
  text-align: center;
  padding: 10px 30px;
  border-radius: 5px;
  font-size: 20px;
  font-weight: bold;
  cursor: pointer;
  transition: color 0.3s;
  position: relative;
  overflow: hidden;
  z-index: 1;
}

.button:after {
  content: "";
  position: absolute;
  top: calc(50% - 10px);
  left: calc(50% - 10px);
  width: 20px;
  height: 20px;
  border-radius: 50%;
  background-color: var(--c-bg);
  transform: scale(0);
  opacity: 0;
  transition: transform 0.3s, opacity 0.3s;
  z-index: -1;
}

.button:hover:after {
  transform: scale(10);
  opacity: 1;
}

.button:hover {
  color: var(--c-text);
}

.button:after {
  transform: scale(0);
  opacity: 0;
}

.button:hover:after {
  transform: scale(10);
  opacity: 1;
}

.cart-inline::before {
  position: absolute;
  content: '';
  bottom: calc(100% - 10px);
  right: 40px;
  width: 0;
  height: 0;
  border-style: solid;
  border-width: 0 0 34px 34px;
  border-color: transparent transparent #fff transparent;
}
</style>
