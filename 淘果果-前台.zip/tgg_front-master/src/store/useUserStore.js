import {defineStore} from "pinia";
import {ref} from "vue";


export const useUserStore = defineStore('user', () => {
    const state = ref({
        isLogin: false,
        showFrom: false,
        loginInfo: {
            password: "",
            username: ""
        },
        userId: ""
    })

    async function login({username, password}) {
        //TODO 获取token 略
        const data = (await $http.post("/api/user/login", {username, password})).data
        const isLogin = data.code === 100
        if (isLogin) {
            $message.success("登录成功")
        }
        state.value.isLogin = isLogin
        state.value.loginInfo = {
            username: isLogin ? username : '',
            password: isLogin ? password : ''
        }
        state.value.userId = data['data'] ?? ""
        return isLogin
    }

    async function register({username, password}) {
        const data = (await $http.post("/api/user/register", {username, password})).data
        const isLogin = data.code === 100
        if (isLogin) {
            $message.success("注册成功")
        }
        state.value.isLogin = isLogin
        state.value.loginInfo = {
            username: isLogin ? username : '',
            password: isLogin ? password : ''
        }
        state.value.userId = data['data'] ?? ""
        return isLogin
    }

    async function initUser() {
        state.value.showFrom = false
        if (state.value.isLogin && state.value.loginInfo.username !== "" && state.value.loginInfo.password !== "") {
            await login(state.value.loginInfo)
            $message.success("欢迎回来!")
        }
    }

    async function logout() {
        if (!state.value.isLogin) {
            $message.warning("请先登录")
            return
        }
        state.value = {
            isLogin: false,
            loginInfo: {
                username: '',
                password: ''
            },
            userId: ""
        }
        $message.info("登出成功")
    }

    return {
        state,
        login,
        logout,
        initUser,
        register
    }

}, {
    persist: true
})
