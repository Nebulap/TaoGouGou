import {defineStore} from "pinia";
import {ref} from "vue";


export const useOrderStore = defineStore("order", () => {
    const state = ref({
        cartList: [],
        showCard:false
    })


    function cleanCart() {
        state.value.cartList = []
    }

    function appendProduct(data) {
        const findProduce = state.value.cartList.find(item => item['produce']['id'] === data['id'])
        $message.success("添加成功")
        if (findProduce) {
            findProduce['number']++
        } else {
            state.value.cartList.push({
                produce: data,
                number: 1
            })
        }
    }

    function increase(id) {
        const findProduce = state.value.cartList.find(item => item['produce']['id'] === id)
        if (findProduce) {
            findProduce['number']++
        }
    }

    function decrease(id) {
        const findProduce = state.value.cartList.find(item => item['produce']['id'] === id)
        if (findProduce) {
            findProduce['number']--
            if (findProduce['number'] === 0) {
                state.value.cartList = state.value.cartList.filter(item => item['produce']['id'] !== id)
            }
        }
    }

    function showCard(){
        state.value.showCard = true
    }

    function closeCard(){
        state.value.showCard = false
    }

    function switchShow(){
        state.value.showCard = !state.value.showCard
    }

    function checkout(){

    }


    return {
        state,
        cleanCart,
        appendProduct,
        increase,
        decrease,
        showCard,
        closeCard,
        switchShow
    }
})
