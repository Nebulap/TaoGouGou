import axios from "axios";


const request = axios.create({
    timeout: 5000
})


function onFulfilled(res) {
    if (res.headers['content-type'].startsWith("image/")){
        return res
    }
    switch (res.data.code) {
        case 100:
            return res;
        case 503:
            $message.error("服务未启动,请联系网站管理员");
            return res
        default:
            $message.warning(res.data['msg'])
            return res;
    }
}

function onRejected(error) {
}

request.interceptors.response.use(onFulfilled, onRejected);

window.$http = request
