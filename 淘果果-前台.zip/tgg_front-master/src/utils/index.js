import { createDiscreteApi } from "naive-ui";

export const { message } = createDiscreteApi(["message"]);
