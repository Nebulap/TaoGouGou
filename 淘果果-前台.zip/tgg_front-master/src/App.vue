<script setup>
import TheHeader from "./components/app/TheHeader.vue";
import TheFooter from "./components/app/TheFooter.vue";

import WOW from "wow.js";
import {onMounted} from "vue";
import {useUserStore} from "./store/useUserStore.js";

const userStore = useUserStore()


onMounted(() => {
  new WOW().init();
  userStore.initUser()
})
</script>

<template>
  <div class="min-h-screen w-full flex flex-col">
    <router-view/>
    <TheFooter/>
  </div>
</template>

<style scoped>
</style>
