import {createApp} from 'vue'
import './style.css'
import App from './App.vue'
import "uno.css"
import "animate.css"
import 'animate.css/animate.compat.css'
import router from './router'
import naive from 'naive-ui'
import {createPinia} from "pinia";
import piniaPluginPersistedstate from "pinia-plugin-persistedstate";
import {message} from './utils'
import './utils/request.js'

const app = createApp(App)


const pinia = createPinia()
pinia.use(piniaPluginPersistedstate)

window.$message = message


app.use(pinia).use(naive).use(router).mount('#app')
