<script setup>
import TheCart from "../../../components/app/TheCart.vue";

defineProps({
  data:{
    type:Object
  }
})
</script>

<template>
  <n-space align="center">
    <div class="bg-[rgb(245,245,245)] w-[108px] h-[108px] flex justify-center items-center cursor-pointer">
      <img :src="data['img']" alt="" class="w-[75px] transition-all-300 hover:scale-110">
    </div>
    <n-space vertical>
      <div>{{data['productName']}}</div>
      <div class="flex justify-center gap-2">
      <span class="decoration-line-through" v-if="data['specialPrice']">
        ¥ {{ data['price'].toFixed(2) }}
      </span>
        <span class="font-bold text-[rgb(67,189,187)]">
        ¥ {{ (data['specialPrice'] ?? data['price'].toFixed(2)) }}
      </span>
      </div>
    </n-space>
  </n-space>
</template>

<style scoped>
</style>
