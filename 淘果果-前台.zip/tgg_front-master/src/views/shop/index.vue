<script setup>

import TheHeader from "../../components/app/TheHeader.vue";
import {computed, onBeforeMount, onBeforeUnmount, ref, watch} from "vue";
import ProduceCard from "../home/model/ProduceCard.vue";
import ProduceCardRow from "./model/ProduceCardRow.vue";
import TheCart from "../../components/app/TheCart.vue";

const hotProduceList = ref([])
const produceList = ref([])
const priceRange = ref([0, 999])
const sortRef = ref("FRESH")
const pagination = ref({
  pageSize: 9,
  page: 1,
  pageCount: 1
})
const allCategory = computed(() => category.value.every(item => item.value))
const allCategoryNumber = ref(0)

const onAllCategory = (value) => {
  category.value.forEach(item => item.value = value)
}

const category = ref([
  {
    label: "酒类",
    value: true,
    number: 0
  },
  {
    label: "蔬菜",
    value: true,
    number: 0
  },
  {
    label: "水果",
    value: true,
    number: 0
  },
  {
    label: "肉类",
    value: true,
    number: 0
  },
  {
    label: "其他",
    value: true,
    number: 0
  }
])

const sortOptions = [
  {
    label: "按新鲜度排序",
    value: "FRESH"
  },
  {
    label: "按名称排序",
    value: "NAME"
  }
]

async function query(page) {
  const params = {
    pageNum: page ?? pagination.value.page - 1,
    pageSize: pagination.value.pageSize,
    max: Math.max(...priceRange.value),
    min: Math.min(...priceRange.value),
    categoryList: !allCategory.value ? category.value.filter(item => item.value).map(item => item.label) : ['全部'],
    sort: sortRef.value
  }
  const res = (await $http.post("/api/produce/getShopProduce", params)).data['data']
  produceList.value = res['pageData']
  pagination.value.pageCount = res['totalPages']
}

function pageChange(current) {
  pagination.value.page = current
  query()
}

const stop1 = watch(category.value, (v) => {
  pagination.value.page = 1
  query()
})

const stop2 = watch(() => sortRef.value, (v) => {
  query()
})

onBeforeMount(async () => {
  const res = (await $http.get("/api/produce/categoryStats")).data['data']
  allCategoryNumber.value =res.reduce((s,c)=>s+c['value'],0)
  res.forEach(item => {
    const i2 =  category.value.find(i => i.label === item['name'])
    if (i2){
      i2.number = item['value']
    }
  })
  hotProduceList.value = (await $http.get("/api/produce/getProduceRanking")).data['data']
  await query()
})

onBeforeUnmount(() => {
  stop1()
  stop2()
})

</script>

<template>
  <n-space vertical class="!gap-0">
    <TheHeader/>
    <div class="header">
      <div class="flex flex-col gap-5 box">
        <div class="text-7xl animate__animated animate__fadeInDown">购物</div>
        <div class="text-2xl max-w-[900px] animate__animated animate__fadeInUp">
          繁华的商场亮着灯光，熙熙攘攘的人群进进出出，有的正准备去购物，有的买完东西，带着满意的微笑高高兴兴的回家。
        </div>
      </div>
    </div>
    <!--    面包屑-->
    <n-space justify="center" align="center" class="bg-[rgb(249,250,249)] py-4 text-[rgb(21,21,21)] text-4 !gap-2">
      <div class="text-gray-500">首页</div>
      <div class="i-ri:arrow-right-s-line"></div>
      <div>购物</div>
    </n-space>

    <!--    购物表格-->

    <n-space class="mx-a mt-30 !gap-15" style="width: max-content">
      <n-space vertical class="!gap-5">
        <!--        价格-->
        <div class="text-[rgb(21,21,21)] text-xl font-bold">
          按价格筛选
        </div>
        <div class="h-[2px] w-full bg-[rgb(0,0,0,0.1)]"></div>
        <n-slider class="w-[280px] slider mt-4" v-model:value="priceRange" range :step="1" :max="999" :min="1">
          <template #thumb>
            <div class="w-[20px] h-[20px] rounded-[50%] bg-[rgb(60,195,193)]"></div>
          </template>
        </n-slider>
        <n-space align="center" class="mt-4">
          <button @click="()=>query(0)"
                  class="bg-[rgb(60,195,193)] cursor-pointer rounded-[5px] text-xl transition-all-300 font-bold p-2 px-6 text-white hover:bg-[rgb(249,233,94)] hover:text-black">
            筛选
          </button>
          <div class="text-4">价格: ¥{{ Math.min(...priceRange) }} - ¥{{ Math.max(...priceRange) }}</div>
        </n-space>
        <!--        类别-->
        <div class="text-[rgb(21,21,21)] text-xl font-bold mt-4">
          类别
        </div>
        <div class="h-[2px] w-full bg-[rgb(0,0,0,0.1)]"></div>
        <n-space align="center" justify="space-between">
          <n-checkbox :checked="allCategory" @update:checked="onAllCategory">
            <n-space align="center" justify="space-between">
              <div>全部</div>
            </n-space>
          </n-checkbox>
          <div class="text-gray-500">({{ allCategoryNumber }})</div>
        </n-space>
        <n-space v-for="item in category" align="center" justify="space-between">
          <n-checkbox v-model:checked="item.value">
            <n-space align="center" justify="space-between">
              <div>{{ item.label }}</div>
            </n-space>
          </n-checkbox>
          <div class="text-gray-500">({{item.number}})</div>
        </n-space>
        <!--        主打产品-->
        <div class="text-[rgb(21,21,21)] text-xl font-bold mt-4">
          主打产品
        </div>
        <div class="h-[2px] w-full bg-[rgb(0,0,0,0.1)]"></div>
        <produce-card-row class="wow fadeInLeft" :data v-for="data in hotProduceList.slice(0,3)"/>
      </n-space>
      <n-space vertical class="!gap-8">
        <n-space align="center" justify="space-between">
          <div>显示第 1 至第 12 条结果，共 28 条</div>
          <n-space align="center">
            <n-select class="w-[150px]" v-model:value="sortRef" :options="sortOptions"/>
            <div class="i-ri:grid-fill text-xl text-[rgb(60,195,193)]"></div>
            <div class="i-ri:list-check text-xl"></div>
          </n-space>
        </n-space>
        <div v-if="produceList.length >0" class="grid grid-cols-3 gap-8 grid-auto-rows-[350px] min-w-[930px] min-h-[1220px]">
          <produce-card class="wow fadeInUp max-w-[290px]" :data="data" v-for="data in produceList"/>
        </div>
        <div v-else class="min-w-[930px] min-h-[1220px] flex flex-col justify-center items-center text-3xl">
          <img src="../../assets/暂无搜索.svg" width="64" height="64" alt=""/>
          <div class="mt-10 text-[#808080]">暂无搜索结果...</div>
        </div>
        <div class="mt-10 mb-30 flex justify-center items-center">
          <n-pagination :page-count="pagination.pageCount" :page="pagination.page" :page-size="pagination.pageSize" @update:page="pageChange">
            <template #prev>
              <div class="i-ri:arrow-left-line text-xl"></div>
            </template>
            <template #next>
              <div class="i-ri:arrow-right-line text-xl"></div>
            </template>
          </n-pagination>
        </div>
      </n-space>
    </n-space>
  </n-space>
</template>

<style scoped>
.header {
  position: relative;
  height: 475px;
  background-image: url("../../assets/bg-about-2.jpg");
  background-position-y: -150px;
  background-size: cover;
  background-repeat: no-repeat;
}

.header::before {
  content: "";
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: rgba(0, 0, 0, 0.3);
  z-index: 1;
}

.header .box {
  position: relative;
  z-index: 2;
  color: white;
  text-align: center;
  height: 100%;
  display: flex;
  justify-content: center;
  align-items: center;
}

.slider >>> .n-slider-rail__fill {
  background-color: rgb(60, 195, 193);
  --n-fill-color-hover: rgb(60, 195, 193);
}

</style>
