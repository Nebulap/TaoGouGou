<script setup>

import TheHeader from "../../components/app/TheHeader.vue";
import {h, onBeforeMount, onMounted, ref} from "vue";
import {NButton, NSpace, NTag} from "naive-ui";
import ProduceCardRow from "../shop/model/ProduceCardRow.vue";
import {useUserStore} from "../../store/useUserStore.js";

const useStore = useUserStore()
const orderList = ref([])
const showDetail = ref(false)
const currentOrder = ref({})

function renderOrderStatus(status) {
  function _getType() {
    switch (status) {
      case "待发货":
        return "default";
      case "已完成":
        return "primary";
      case "已取消":
        return "warning";
      case "已发货":
        return "info";
    }
  }

  return h(NTag, { type: _getType() }, () => status);
}
const columns = [
  {
    title: "订单编号",
    key: "id"
  },
  {
    title: "收货地址",
    key: "deliveryAddress"
  },
  {
    title: "下单时间",
    key: "createdAt"
  },
  {
    title:"订单状态",
    key: "orderStatus",
    render: (row) => renderOrderStatus(row["orderStatus"]),
  },
  {
    title: "金额",
    key: "totalPrice",
    render: (row) => h("span", null, ` ¥ ${row['totalPrice']}`)
  },
  {
    title: "支付方式",
    key: "paymentMethod"
  },
  {
    title: "操作",
    render: (row) => h(NButton, {type: 'tertiary', onClick: () => showDetailId(row['id'])}, () => '查看详情')
  }
]

function showDetailId(id) {
  currentOrder.value = orderList.value.find(item => item.id === id)
  showDetail.value = true
}

onBeforeMount(async () => {
  if (useStore.state.isLogin){
    orderList.value = (await $http.get("/api/order/" + useStore.state.userId)).data['data']
  }

})
</script>

<template>
  <TheHeader/>
  <div class="flex flex-col min-h-[900px]">
    <div class="flex flex-col shadow-xl p-8 bg-[#f8f8f8ff] w-[1200px] mx-a">
      <div class="text-xl text-[#333]">我的订单</div>
      <n-data-table striped class="bg-white" :columns="columns" :data="orderList"/>
    </div>

  </div>

  <n-modal v-model:show="showDetail" closable>
    <n-space vertical class="bg-white px-10 py-5 min-w-[700px]">
      <div class="text-2xl">订单详情</div>
      <div class="max-h-[400px] overflow-y-auto">
        <n-space vertical v-for="data in currentOrder['products']" class="mb-3">
          <n-space align="center">
            <div class="bg-[rgb(245,245,245)] w-[108px] h-[108px] flex justify-center items-center cursor-pointer">
              <img :src="data['produce']['img']" alt="" class="w-[75px] transition-all-300 hover:scale-110">
            </div>
            <n-space vertical>
              <div class="text-4">{{ data['produce']['productName'] }} * {{ data['number'] }}</div>
              <div class="text-red-600 text-5 font-bold">¥ {{ (data['produce']['price'] * data['number']).toFixed(2) }}</div>
            </n-space>
          </n-space>
        </n-space>
      </div>
      <n-space justify="end">
        <n-button type="default" @click="()=>showDetail = false">确认</n-button>
      </n-space>
    </n-space>
  </n-modal>
</template>

<style scoped>

</style>
