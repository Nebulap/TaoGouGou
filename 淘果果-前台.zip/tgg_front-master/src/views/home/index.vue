<script setup>
import ProduceCard from "./model/ProduceCard.vue";
import AboutUs from "./model/AboutUs.vue";
import DataModel from "./model/DataModel.vue";
import TheHeader from "../../components/app/TheHeader.vue";
import {onBeforeMount, onMounted, ref} from "vue";

const hotProduceList = ref([])

onBeforeMount(async ()=>{
  hotProduceList.value = (await $http.get("/api/produce/getProduceRanking")).data['data']
})

</script>

<template>
  <TheHeader is-home/>
  <n-space vertical>
    <!--    产品展示区-->
    <div class="text-3xl font-bold my-10 wow fadeInUp text-center">产品介绍</div>
    <n-space justify="center" align="center" class=" h-[620px] q1">
      <n-space vertical class="wow bounceInLeft">
        <n-space>
          <n-space vertical class="text-end">
            <div class="text-2xl font-bold hover:text-[rgb(60,195,193)] transition-all">100% 有机</div>
            <div class="max-w-[270px]">我们的产品由100%有机和新鲜的成分制成，富含维生素和营养物质.</div>
          </n-space>
          <div class="rounded-[50%] transition-all shadow-lg p-4 bg-white text-black hover:bg-[rgb(60,195,193)] hover:text-white">
            <div class="i-ri:search-line text-4xl"></div>
          </div>
        </n-space>
        <div class="bg-gray-300 w-[320px] h-[1px] my-15"></div>
        <n-space>
          <n-space vertical class="text-end">
            <div class="text-2xl font-bold hover:text-[rgb(60,195,193)] transition-all">有益健康</div>
            <div class="max-w-[270px]">我们的产品对促进您的健康和提高您的能量水平非常有益。</div>
          </n-space>
          <div class="rounded-[50%] transition-all shadow-lg p-4 bg-white text-black hover:bg-[rgb(60,195,193)] hover:text-white">
            <div class="i-ri:search-line text-4xl"></div>
          </div>
        </n-space>
      </n-space>
      <img src="../../assets/index-1-399x407.png" class="wow bounceIn">
      <n-space vertical class="wow bounceInRight">
        <n-space>
          <div class="rounded-[50%] transition-all shadow-lg p-4 bg-white text-black hover:bg-[rgb(60,195,193)] hover:text-white">
            <div class="i-ri:search-line text-4xl"></div>
          </div>
          <n-space vertical>
            <div class="text-2xl font-bold hover:text-[rgb(60,195,193)] transition-all">无添加剂</div>
            <div class="max-w-[270px]">我们的食品和饮料不含人工添加剂，只含有您身体所需的重要元素.</div>
          </n-space>
        </n-space>
        <div class="bg-gray-300 w-[320px] h-[1px] my-15"></div>
        <n-space>
          <div class="rounded-[50%] transition-all shadow-lg p-4 bg-white text-black hover:bg-[rgb(60,195,193)] hover:text-white">
            <div class="i-ri:search-line text-4xl"></div>
          </div>
          <n-space vertical>
            <div class="text-2xl font-bold hover:text-[rgb(60,195,193)] transition-all">精力充沛</div>
            <div class="max-w-[270px]">我们将产品设计为最终的纯素和有机能源，适合您日常生活.</div>
          </n-space>
        </n-space>
      </n-space>
    </n-space>
    <!--    主打产品-->
    <n-space vertical align="center" class="bg-white px-30">
      <div class="text-3xl font-bold my-10 wow fadeInUp text-center">主打产品</div>
      <div class="grid grid-cols-4 gap-8 grid-auto-rows-[350px]">
        <produce-card class="wow fadeInRight" :data="produce" v-for="produce in hotProduceList"/>
      </div>
    </n-space>
    <!--    数据展示区-->
    <data-model />
    <!--    关于我们-->
    <AboutUs/>
    <!--    人们怎么说-->
    <n-space vertical align="center" class="mt-20 q1 py-25">
      <div class="text-3xl font-bold mb-10 wow fadeInLeft">人们怎么说</div>
      <div class="max-w-[700px] text-4 line-height-relaxed text-center mb-9 text-[rgb(119,119,119)] wow fadeInRight">健康绿色的有机食品</div>
      <n-space justify="center" class="!gap-40">
        <n-space v-for="_ in 3" vertical align="center" class="wow fadeInUp">
          <n-avatar circle :size="90"></n-avatar>
          <div class="font-bold">小明</div>
          <div class="text-[rgb(67,190,188)] italic">客户</div>
        </n-space>
      </n-space>
    </n-space>
  </n-space>
</template>

<style scoped>
.q1 {
  background-image: url("../../assets/bg-pattern-1.jpg");
}

.sx {
  height: 400px;
  background-image: url("../../assets/parallax-2.jpg");
}


</style>
