<script setup>
import {nextTick, onBeforeUnmount, onMounted, ref} from "vue";

//用户总数
//订单总数
//农场数量
//产品数量

const userCount = ref(0);
const orderCount = ref(0);
const farmCount = ref(0);
const productCount = ref(0);
const count = ref([
  {
    label: "用户总数",
    value: 0
  },
  {
    label: "订单总数",
    value: 0
  },
  {
    label: '农场数量',
    value: 0
  },
  {
    label: "产品数量",
    value: 0
  }
])

// 视差滚动元素
const sx = ref(null)

const handleIntersection = (entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      count.value = [
        {
          label: "用户总数",
          value: 200
        },
        {
          label: "订单总数",
          value: 301
        },
        {
          label: '农场数量',
          value: 30
        },
        {
          label: "产品数量",
          value: 130
        }
      ]
    }
  });
};


const handleScroll = () => {
  if (sx.value) {
    const scrolled = window.scrollY;
    sx.value.style.backgroundPositionY = `${scrolled * 0.3}px`;
  }
};

onMounted(async () => {
  await nextTick();
  window.addEventListener('scroll', handleScroll);
  const observer = new IntersectionObserver(handleIntersection);
  if (sx.value) {
    observer.observe(sx.value);
  }
});

onBeforeUnmount(() => {
  window.removeEventListener('scroll', handleScroll);
})
</script>

<template>
  <div class="block sx !gap-40 mt-20 mb-20  flex justify-center items-center" ref="sx">
    <n-space v-for="item in count" vertical align="center" justify="center">
        <span class="text-6xl text-white font-bold">
                    <n-number-animation
                        show-separator
                        :from="0"
                        :to="item.value"
                        active
                    />
        </span>
      <div class="bg-white w-[50px] h-[1px] my-3"></div>
      <span class="text-2xl text-white font-bold">
          {{ item.label }}
        </span>
    </n-space>
  </div>
</template>

<style scoped>

</style>
