<script setup>

import {useOrderStore} from "../../../store/useOrderStore.js";

defineProps({
  data: {
    type: Object
  }
})

const orderStore = useOrderStore()



</script>

<template>
  <div>
    <div class="in">
      <n-space vertical class="bg-[rgb(245,245,245)] p-3 rounded-xl card">
        <div class="text-end mb-8">
      <span class="bg-red-400 p-1 px-3 rounded font-bold text-white">
        Sale
      </span>
        </div>
        <div class="px-8 h-[134px]">
          <img :src="data['img']" alt="" class="object-contain w-full h-full">
        </div>
        <div class="text-center text-xl mb-4">
          {{ data['productName'] }}
        </div>
        <div class="flex justify-center gap-2 mb-8">
      <span class="decoration-line-through" v-if="data['specialPrice']">
        ¥ {{ data['price'].toFixed(2) }}
      </span>
          <span class="font-bold text-[rgb(67,189,187)]">
        ¥ {{ (data['specialPrice'] ?? data['price'].toFixed(2)) }}
      </span>
        </div>
        <div class=" button hidden">
          <button class="cursor-pointer animate__bounceIn animate__animated bg-[rgb(249,233,94)] p-4 rounded-[50%]">
            <div class="i-ri:search-line text-xl"></div>
          </button>
          <button class="cursor-pointer animate__bounceIn animate__animated bg-[rgb(60,195,193)] p-4 rounded-[50%]" @click="()=>orderStore.appendProduct(data)">
            <div class="i-ri:shopping-cart-2-line text-xl text-white"></div>
          </button>
        </div>
      </n-space>
    </div>
  </div>
</template>

<style scoped>
.card {
  transition: all 0.5s;
  height: max-content;
}

.in {
  animation-fill-mode: forwards;
  animation-name: in;
  animation-duration: 0.5s;
}

.card:hover {
  z-index: 5;
  transform: translateY(-20px);
  background-color: white;
  box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
  animation: heightI 0.3s forwards;
}

@keyframes in {
  0%{
    opacity: 0;
  }
  100%{
    opacity: 1;
  }
}

.button {
  overflow: hidden;
}

.card:hover .button {
  display: flex;
  justify-content: center;
  gap: 25px;
}

@keyframes heightI {
  0% {
    height: 350px;
  }

  100% {
    height: 400px;
  }
}

</style>
