<script setup>
const aboutUsList = [
  '欢迎来到我们的电商平台，一个致力于扶贫和支持农民的农产品购物网站。我们坚信，通过电商平台的力量，可以将优质、健康的农产品直接从田间送到您的餐桌，同时帮助贫困地区的农民增加收入，改善生活。',
  '我们的使命是通过销售天然、有机和健康的农产品，帮助贫困农民拓宽销路，提升他们的经济能力。我们与当地农户紧密合作，确保每一件产品都经过严格筛选和质量控制，以保证新鲜和高品质。',
  '我们提供的产品种类丰富，包括新鲜的水果蔬菜、纯天然的蜂蜜、手工制作的农副产品等。每一件商品都凝聚了农民的辛勤劳动和我们对品质的承诺。',
  '选择我们，您不仅可以享受到优质的农产品，还在为扶贫事业贡献一份力量。感谢您的支持，让我们一起携手，共同创造一个更加美好的未来！'
]
</script>

<template>
  <n-space vertical align="center">
    <div class="font-bold text-3xl text-center text-[#43bdbb] mb-15 wow fadeInUp">关于我们</div>
    <div class="grid grid-cols-4 gap-6">
      <div v-for="item in aboutUsList" class="p-10 max-w-[250px] text-xl line-height-loose indent-2xl bg-gray-100 rounded-xl shadow-lg wow fadeInLeft">
        {{item}}
      </div>
    </div>
  </n-space>
</template>

<style scoped>

</style>
