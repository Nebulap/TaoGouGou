package com.forest.ds.file.request;

import lombok.Data;
import org.springframework.web.multipart.MultipartFile;

/**
 * @author 29002
 * @since 2024/6/19 下午8:58
 */
@Data
public class FilePutRequest {
    private MultipartFile file;
}
