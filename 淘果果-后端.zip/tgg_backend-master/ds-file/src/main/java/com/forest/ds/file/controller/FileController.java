package com.forest.ds.file.controller;

import com.forest.ds.file.request.FilePutRequest;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import com.forest.ds.file.service.FileService;

import java.io.IOException;

@RequiredArgsConstructor
@RequestMapping("/file")
@RestController
public class FileController {
    private final FileService fileService;

    @PutMapping("/img")
    public Object upload(@ModelAttribute FilePutRequest filePutRequest, HttpServletRequest request) throws IOException {
        return fileService.uploadImage(filePutRequest.getFile(), request);
    }

//    @PutMapping("/file/imgs")
//    public Object upload(@RequestAttribute MultipartFile[] files, HttpServletRequest request) throws IOException {
//        return Arrays.stream(files).map(file -> {
//            try {
//                return fileService.uploadImage(file, request);
//            } catch (IOException e) {
//                throw new RuntimeException(e);
//            }
//        }).toList();
//    }

    @GetMapping("/{fileName}")
    public Object loadImage(@PathVariable("fileName") String fileName, HttpServletRequest request) throws IOException {
        System.out.println("123");
        return fileService.loadImage(fileName, request);
    }
}
