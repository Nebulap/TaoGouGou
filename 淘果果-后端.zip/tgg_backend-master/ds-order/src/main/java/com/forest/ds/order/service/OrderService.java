package com.forest.ds.order.service;

import com.forest.ds.common.core.PageResponse;
import com.forest.ds.common.domain.entity.Order;
import com.forest.ds.order.domain.dto.HotSaleDto;
import com.forest.ds.order.domain.dto.OrderAnalysisDto;
import com.forest.ds.order.domain.dto.OrderProfitTotalDto;
import com.forest.ds.order.domain.request.OrderAddRequest;
import com.forest.ds.order.domain.request.OrderAnalysisRequest;
import com.forest.ds.order.domain.request.OrderPageRequest;
import com.forest.ds.order.domain.request.OrderProfitStatsRequest;
import org.aspectj.weaver.ast.Or;

import java.util.List;

/**
 * @author 29002
 * @since 2024/6/14 上午9:37
 */
public interface OrderService {
    PageResponse getPage(OrderPageRequest request);
    List<OrderAnalysisDto> orderAnalysis(OrderAnalysisRequest request);
    OrderProfitTotalDto getOrderProfitStats(OrderProfitStatsRequest request);
    OrderProfitTotalDto getOrderTotalPriceStats(OrderProfitStatsRequest request);
    List<HotSaleDto> getHotSale();
    List<Order> getOrderByUserId(Integer uid);
    void add(OrderAddRequest request);
    Order getOrderById(Integer id);
    void update(Order order);
}
