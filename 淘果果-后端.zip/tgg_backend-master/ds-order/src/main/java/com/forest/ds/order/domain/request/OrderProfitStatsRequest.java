package com.forest.ds.order.domain.request;

import lombok.Data;

/**
 * @author 29002
 * @since 2024/6/15 下午5:19
 */
@Data
public class OrderProfitStatsRequest {
    private Integer comparedMonth;
    private Integer month;
}
