package com.forest.ds.order.repository;

import com.forest.ds.common.domain.entity.OrderProduceList;
import com.forest.ds.order.domain.dto.HotSaleDto;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface OrderProduceListRepository extends JpaRepository<OrderProduceList, Integer>, JpaSpecificationExecutor<OrderProduceList> {

    @Query("select produce.productName as name,sum(number) as value from OrderProduceList " +
            "group by produce.id " +
            "order by value desc")
    List<HotSaleDto> getHotSale(Pageable pageable);
}
