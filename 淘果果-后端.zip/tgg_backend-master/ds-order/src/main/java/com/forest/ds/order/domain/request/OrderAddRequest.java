package com.forest.ds.order.domain.request;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.forest.ds.common.domain.entity.OrderProduceList;
import jakarta.persistence.*;
import lombok.Data;
import org.hibernate.annotations.ColumnDefault;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.List;

/**
 * @author 29002
 * @since 2024/6/21 下午11:31
 */
@Data
public class OrderAddRequest {
    private Integer customerId;
    private List<ProductOrderRequest> products;
    private BigDecimal totalPrice;
    private BigDecimal totalProfit;
    private Integer quantity;
    private BigDecimal hideProfit;
    private String orderStatus = "待发货";
    private Instant orderDate = Instant.now();
    private String deliveryAddress;
    private String paymentMethod = "微信支付";
}
