package com.forest.ds.order.domain.request;


import com.forest.ds.common.domain.request.CommonPageRequest;

/**
 * @author 29002
 * @since 2024/6/16 上午1:19
 */
public class RefundPageRequest extends CommonPageRequest {
}
