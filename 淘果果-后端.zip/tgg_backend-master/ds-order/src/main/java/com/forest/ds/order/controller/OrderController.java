package com.forest.ds.order.controller;


import com.forest.ds.common.core.PageResponse;
import com.forest.ds.common.domain.entity.Order;
import com.forest.ds.order.domain.dto.HotSaleDto;
import com.forest.ds.order.domain.dto.OrderAnalysisDto;
import com.forest.ds.order.domain.dto.OrderProfitTotalDto;
import com.forest.ds.order.domain.request.OrderAddRequest;
import com.forest.ds.order.domain.request.OrderAnalysisRequest;
import com.forest.ds.order.domain.request.OrderPageRequest;
import com.forest.ds.order.domain.request.OrderProfitStatsRequest;
import com.forest.ds.order.service.OrderService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * @author 29002
 * @since 2024/6/14 上午10:13
 */
@RestController
@RequiredArgsConstructor
@RequestMapping("/order")
public class OrderController {
    private final OrderService orderService;

    @PostMapping
    public PageResponse getOrders(@RequestBody OrderPageRequest request) {
        return orderService.getPage(request);
    }

    @GetMapping("/analysis")
    public List<OrderAnalysisDto> getOrderAnalysis(OrderAnalysisRequest request) {
        return orderService.orderAnalysis(request);
    }

    @GetMapping("/orderProfitStats")
    public OrderProfitTotalDto getOrderProfitStats(OrderProfitStatsRequest request) {
        return orderService.getOrderProfitStats(request);
    }

    @GetMapping("/orderPriceTotalStats")
    public OrderProfitTotalDto getOrderPriceTotalStats(OrderProfitStatsRequest request) {
        return orderService.getOrderTotalPriceStats(request);
    }

    @GetMapping("/getHotSale")
    public List<HotSaleDto> getHotSale() {
        return orderService.getHotSale();
    }

    @GetMapping("{uid}")
    public List<Order> getOrderByUserId(@PathVariable("uid") Integer uid) {
        return orderService.getOrderByUserId(uid);
    }

    @PostMapping("add")
    public void add(@RequestBody OrderAddRequest request){
        orderService.add(request);
    }

    @GetMapping("/id/{id}")
    public Order getOrderById(@PathVariable("id") Integer id) {
        return orderService.getOrderById(id);
    }

    @PutMapping
    public void update(@RequestBody Order order){
        orderService.update(order);
    }
}
