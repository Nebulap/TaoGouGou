package com.forest.ds.order.domain.spec;

import com.forest.ds.common.core.BaseSpecification;
import com.forest.ds.common.domain.entity.Refund;
import org.springframework.stereotype.Component;

/**
 * @author 29002
 * @since 2024/6/16 上午1:20
 */
@Component
public class RefundSpecification extends BaseSpecification<Refund> {
}
