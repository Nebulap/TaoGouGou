package com.forest.ds.order.domain.spec;

import com.forest.ds.common.core.BaseSpecification;
import com.forest.ds.common.domain.entity.AgriculturalProduct;
import com.forest.ds.common.domain.entity.Order;
import com.forest.ds.order.domain.request.OrderPageRequest;
import jakarta.persistence.criteria.Join;
import jakarta.persistence.criteria.Predicate;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

/**
 * @author 29002
 * @since 2024/6/14 下午9:25
 */
@Component
public class OrderSpecification extends BaseSpecification<Order> {

    public Specification<Order> getPageAndCustomSpecification(OrderPageRequest request) {
        return getCustomQuerySpecification(getPageSpecification(request), request);
    }

    public Specification<Order> getPageSpecification(OrderPageRequest request) {
        return (root, query, criteriaBuilder) -> {
            List<Predicate> predicates = new ArrayList<>();
            if (request.getId() != null) {
                predicates.add(criteriaBuilder.equal(root.get("id"), request.getId()));
            }
            if (request.getUid() != null && !request.getUid().isEmpty()) {
                predicates.add(criteriaBuilder.equal(root.get("uid"), request.getUid()));
            }
            if (request.getOrderStatus() != null && !request.getOrderStatus().isEmpty()) {
                predicates.add(criteriaBuilder.equal(root.get("orderStatus"), request.getOrderStatus()));
            }
            if (request.getProductName()!= null && !request.getProductName().isEmpty()) {
                Join<Order, AgriculturalProduct> productJoin = root.join("product");
                predicates.add(criteriaBuilder.like(productJoin.get("productName"), "%" + request.getProductName() + "%"));
            }
            predicates.add(criteriaBuilder.notEqual(root.get("orderStatus"),"占位"));
            return criteriaBuilder.and(predicates.toArray(new Predicate[0]));
        };
    }
}
