package com.forest.ds.order.controller;

import com.forest.ds.common.core.PageResponse;
import com.forest.ds.order.domain.dto.RefundPageDto;
import com.forest.ds.order.domain.request.RefundPageRequest;
import com.forest.ds.order.service.RefundService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

/**
 * @author 29002
 * @since 2024/6/16 上午12:50
 */
@RestController
@RequestMapping("/refund")
@RequiredArgsConstructor
public class RefundController {
    private final RefundService refundService;



    @PostMapping("/page")
    public PageResponse getPage(@RequestBody RefundPageRequest request) {
        return refundService.page(request);
    }
}
