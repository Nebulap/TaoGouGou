package com.forest.ds.order.domain.request;

import lombok.Data;

@Data
public class ProductOrderRequest {
    private Integer productId;
    private Integer number;
}
