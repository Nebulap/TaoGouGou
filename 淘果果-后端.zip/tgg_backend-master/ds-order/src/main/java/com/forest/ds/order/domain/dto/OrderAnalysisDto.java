package com.forest.ds.order.domain.dto;

import lombok.Data;

/**
 * @author 29002
 * @since 2024/6/15 下午2:50
 */
public interface OrderAnalysisDto {
    public String getDate();

    public Integer getProfit();

    public Integer getTotal();

    public Integer getHideProfit();
}
