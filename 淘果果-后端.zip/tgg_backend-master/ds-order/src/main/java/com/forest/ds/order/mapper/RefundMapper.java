package com.forest.ds.order.mapper;

import com.forest.ds.common.domain.entity.Refund;
import com.forest.ds.common.mapstruct.MapStruckConfig;
import com.forest.ds.order.domain.dto.RefundPageDto;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

/**
 * @author 29002
 * @since 2024/6/16 上午12:58
 */
@Mapper(componentModel = MapStruckConfig.MODEL)
public interface RefundMapper {
    @Mapping(target = "customer",ignore = true)
    RefundPageDto toPageDto(Refund refund);
}
