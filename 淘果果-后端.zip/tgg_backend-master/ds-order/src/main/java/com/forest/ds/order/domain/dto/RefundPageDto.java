package com.forest.ds.order.domain.dto;

import com.forest.ds.common.domain.dto.UserDto;
import com.forest.ds.common.domain.entity.Order;
import com.forest.ds.common.domain.entity.User;
import jakarta.persistence.*;
import lombok.Data;
import org.hibernate.annotations.ColumnDefault;

import java.math.BigDecimal;
import java.time.Instant;

/**
 * @author 29002
 * @since 2024/6/16 上午12:53
 */
@Data
public class RefundPageDto {
    private Integer id;
    private BigDecimal refundAmount;
    private String refundReason;
    private String refundStatus;
    private Instant requestDate;
    private Instant processedDate;
    private String remarks;
    private UserDto customer;
    private Order order;
}
