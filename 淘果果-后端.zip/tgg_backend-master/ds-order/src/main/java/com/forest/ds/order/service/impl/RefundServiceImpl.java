package com.forest.ds.order.service.impl;

import com.forest.ds.common.core.PageResponse;
import com.forest.ds.common.domain.entity.Order;
import com.forest.ds.common.domain.entity.Refund;
import com.forest.ds.order.domain.request.RefundPageRequest;
import com.forest.ds.order.domain.spec.RefundSpecification;
import com.forest.ds.order.repository.RefundRepository;
import com.forest.ds.order.service.RefundService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

/**
 * @author 29002
 * @since 2024/6/16 上午12:51
 */
@Service
@RequiredArgsConstructor
public class RefundServiceImpl implements RefundService {
    private final RefundRepository refundRepository;
    private final RefundSpecification refundSpecification;

    @Override
    public PageResponse page(RefundPageRequest request) {
        Specification<Refund> specification = refundSpecification.getCustomQuerySpecification(request);
        Pageable pageable = request.buildPageable();
        Page<Refund> orders = refundRepository.findAll(specification, pageable);
        return PageResponse.of(orders.getContent(), orders.getTotalPages());
    }
}
