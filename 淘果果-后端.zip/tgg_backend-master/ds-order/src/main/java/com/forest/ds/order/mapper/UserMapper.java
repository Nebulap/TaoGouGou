package com.forest.ds.order.mapper;

import com.forest.ds.common.domain.dto.UserDto;
import com.forest.ds.common.domain.entity.User;
import com.forest.ds.common.mapstruct.MapStruckConfig;
import org.mapstruct.Mapper;

/**
 * @author 29002
 * @since 2024/6/16 上午1:13
 */
@Mapper(componentModel = MapStruckConfig.MODEL)
public interface UserMapper {
    UserDto userToUserDto(User user);
}
