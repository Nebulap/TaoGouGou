package com.forest.ds.order.domain.dto;

/**
 * @author 29002
 * @since 2024/6/15 下午11:47
 */
public interface HotSaleDto {
    String getName();

    Integer getValue();
}
