package com.forest.ds.order.domain.request;

import com.forest.ds.common.enums.TimeRange;
import lombok.Data;

/**
 * @author 29002
 * @since 2024/6/15 下午3:16
 */
@Data
public class OrderAnalysisRequest {
    private TimeRange range;
}
