package com.forest.ds.order.domain.request;

import com.forest.ds.common.domain.request.CommonPageRequest;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @author 29002
 * @since 2024/6/14 下午9:20
 */
@EqualsAndHashCode(callSuper = true)
@Data
public class OrderPageRequest extends CommonPageRequest {
    private Integer id;
    private String uid;
    private String orderStatus;
    private String paymentMethod;
    private String productName;
}
