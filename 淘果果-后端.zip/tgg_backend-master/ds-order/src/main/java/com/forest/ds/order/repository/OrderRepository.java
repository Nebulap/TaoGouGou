package com.forest.ds.order.repository;

import com.forest.ds.common.domain.entity.Order;
import com.forest.ds.order.domain.dto.HotSaleDto;
import com.forest.ds.order.domain.dto.OrderAnalysisDto;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.math.BigDecimal;
import java.time.Instant;
import java.time.LocalDate;
import java.time.Period;
import java.util.List;
import java.util.Optional;

public interface OrderRepository extends JpaRepository<Order, Integer>, JpaSpecificationExecutor<Order> {
    Instant LAST_7_DAYS = Instant.now().minus(Period.ofDays(6));
    Instant LAST_30_DAYS = Instant.now().minus(Period.ofDays(29));

    @Query("SELECT DATE(orderDate) AS date, SUM(totalPrice) AS total," +
            "sum(totalProfit) AS profit," +
            "sum(hideProfit) as hideProfit FROM Order " +
            "WHERE orderDate>= :p " +
            "GROUP BY DATE(orderDate) ORDER BY date(orderDate)")
    List<OrderAnalysisDto> getLastDays(@Param("p") Instant p);

    @Query("SELECT sum(totalProfit) FROM Order WHERE  MONTH(orderDate) = :month")
    BigDecimal getMonthProfit(@Param("month") Integer month);

    @Query("SELECT sum(totalPrice) FROM Order WHERE  MONTH(orderDate) = :month")
    BigDecimal getMonthPriceTotal(@Param("month") Integer month);

    List<Order> getOrdersByCustomerId(Integer uid);

    Order getOrdersById(Integer id);
}
