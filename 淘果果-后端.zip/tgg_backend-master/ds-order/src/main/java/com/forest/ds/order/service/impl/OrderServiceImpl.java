package com.forest.ds.order.service.impl;

import com.forest.ds.common.core.PageResponse;
import com.forest.ds.common.domain.entity.AgriculturalProduct;
import com.forest.ds.common.domain.entity.Order;
import com.forest.ds.common.domain.entity.OrderProduceList;
import com.forest.ds.order.domain.dto.HotSaleDto;
import com.forest.ds.order.domain.dto.OrderAnalysisDto;
import com.forest.ds.order.domain.dto.OrderProfitTotalDto;
import com.forest.ds.order.domain.request.OrderAddRequest;
import com.forest.ds.order.domain.request.OrderAnalysisRequest;
import com.forest.ds.order.domain.request.OrderPageRequest;
import com.forest.ds.order.domain.request.OrderProfitStatsRequest;
import com.forest.ds.order.domain.spec.OrderSpecification;
import com.forest.ds.order.mapper.AgriculturalProductRepository;
import com.forest.ds.order.mapper.OrderMapper;
import com.forest.ds.order.repository.OrderProduceListRepository;
import com.forest.ds.order.repository.OrderRepository;
import com.forest.ds.order.service.OrderService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.Instant;
import java.util.List;
import java.util.stream.Collectors;

/**
 * @author 29002
 * @since 2024/6/14 上午9:37
 */
@Service
@RequiredArgsConstructor
public class OrderServiceImpl implements OrderService {
    private final OrderRepository orderRepository;
    private final OrderSpecification orderSpecification;
    private final OrderProduceListRepository orderProduceListRepository;
    private final OrderMapper orderMapper;
    private final AgriculturalProductRepository agriculturalProductRepository;

    @Override
    public PageResponse getPage(OrderPageRequest request) {
        Specification<Order> specification = orderSpecification.getPageAndCustomSpecification(request);
        Pageable pageable = request.buildPageable();
        Page<Order> orders = orderRepository.findAll(specification, pageable);
        return PageResponse.of(orders.getContent(), orders.getTotalPages());
    }

    @Override
    public List<OrderAnalysisDto> orderAnalysis(OrderAnalysisRequest request) {
        Instant instant = Instant.now();
        switch (request.getRange()) {
            case LAST_7_DAYS -> instant = OrderRepository.LAST_7_DAYS;
            case LAST_30_DAYS -> instant = OrderRepository.LAST_30_DAYS;
        }
        return orderRepository.getLastDays(instant);
    }

    @Override
    public OrderProfitTotalDto getOrderProfitStats(OrderProfitStatsRequest request) {
        BigDecimal lastMonthProfit = orderRepository.getMonthProfit(request.getComparedMonth());
        BigDecimal currentMonthProfit = orderRepository.getMonthProfit(request.getMonth());
        return calculationProfit(lastMonthProfit, currentMonthProfit);
    }

    @Override
    public OrderProfitTotalDto getOrderTotalPriceStats(OrderProfitStatsRequest request) {
        BigDecimal lastMonthProfit = orderRepository.getMonthPriceTotal(request.getComparedMonth());
        BigDecimal currentMonthProfit = orderRepository.getMonthPriceTotal(request.getMonth());
        return calculationProfit(lastMonthProfit, currentMonthProfit);
    }

    @Override
    public List<HotSaleDto> getHotSale() {
        Pageable pageable = PageRequest.of(0, 10);
        return orderProduceListRepository.getHotSale(pageable);
    }

    @Override
    public List<Order> getOrderByUserId(Integer uid) {
        return orderRepository.getOrdersByCustomerId(uid);
    }

    @Override
    @Transactional
    public void add(OrderAddRequest request) {
        // 将 OrderAddRequest 转换为 Order 实体
        Order order = orderMapper.toOrder(request);

        // 保存 Order 实体，生成订单ID
        Order savedOrder = orderRepository.save(order);

        // 创建订单项列表
        List<OrderProduceList> produceLists = request.getProducts().stream().map(i -> {
            AgriculturalProduct ap = agriculturalProductRepository.findAgriculturalProductById(i.getProductId());

            OrderProduceList orderProduceList = new OrderProduceList();
            orderProduceList.setOrder(savedOrder);  // 直接设置已保存的订单
            orderProduceList.setNumber(i.getNumber());
            orderProduceList.setProduce(ap);

            return orderProduceList;
        }).collect(Collectors.toList());

        // 批量保存订单项
         orderProduceListRepository.saveAll(produceLists);
    }

    @Override
    public Order getOrderById(Integer id) {
        return  orderRepository.getOrdersById(id);
    }

    @Transactional
    @Override
    public void update(Order order) {
        orderRepository.save(order);
    }

    public OrderProfitTotalDto calculationProfit(BigDecimal lastMonthProfit, BigDecimal currentMonthProfit) {
        // 计算增长百分比
        BigDecimal increasePercentage = BigDecimal.ZERO;
        if (lastMonthProfit != null && lastMonthProfit.compareTo(BigDecimal.ZERO) != 0) {
            increasePercentage = currentMonthProfit.subtract(lastMonthProfit)
                    .divide(lastMonthProfit, 2, RoundingMode.HALF_UP)
                    .multiply(new BigDecimal(100));
        }

        return new OrderProfitTotalDto(currentMonthProfit.toBigInteger().intValue(), increasePercentage);
    }

}
