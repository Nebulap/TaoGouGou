package com.forest.ds.order.domain.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.math.BigDecimal;

/**
 * @author 29002
 * @since 2024/6/15 下午4:31
 */
@Data
@AllArgsConstructor
public class OrderProfitTotalDto {
    private Integer total;
    private BigDecimal difference;
}
