package com.forest.ds.order.mapper;

import com.forest.ds.common.domain.entity.AgriculturalProduct;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

//TODO 本来应该使用openFeign调用Product服务 懒得弄
public interface AgriculturalProductRepository extends JpaRepository<AgriculturalProduct, Integer>, JpaSpecificationExecutor<AgriculturalProduct> {
  AgriculturalProduct findAgriculturalProductById(Integer id);
}
