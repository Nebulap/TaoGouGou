package com.forest.ds.order.mapper;

import com.forest.ds.common.domain.entity.Order;
import com.forest.ds.common.mapstruct.MapStruckConfig;
import com.forest.ds.order.domain.request.OrderAddRequest;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

/**
 * @author 29002
 * @since 2024/6/21 下午11:34
 */
@Mapper(componentModel = MapStruckConfig.MODEL)
public interface OrderMapper {
    @Mapping(target = "products", ignore = true)
    Order toOrder(OrderAddRequest request);
}
