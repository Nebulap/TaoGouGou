package com.forest.ds.order.repository;

import com.forest.ds.common.domain.entity.Refund;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

public interface RefundRepository extends JpaRepository<Refund, Integer>, JpaSpecificationExecutor<Refund> {
}
