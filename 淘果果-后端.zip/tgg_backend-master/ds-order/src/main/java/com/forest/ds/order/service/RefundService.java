package com.forest.ds.order.service;

import com.forest.ds.common.core.PageResponse;
import com.forest.ds.order.domain.request.RefundPageRequest;

/**
 * @author 29002
 * @since 2024/6/16 上午12:51
 */
public interface RefundService {
    PageResponse page(RefundPageRequest request);
}
