package com.forest.ds.gateway;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DsGatewayApplication {

    public static void main(String[] args) {
        SpringApplication.run(DsGatewayApplication.class, args);
    }

}
