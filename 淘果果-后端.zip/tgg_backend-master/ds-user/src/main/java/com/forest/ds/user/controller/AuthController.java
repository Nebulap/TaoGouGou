package com.forest.ds.user.controller;

import com.forest.ds.user.domain.request.AuthLoginRequest;
import com.forest.ds.user.domain.request.UserRegisterRequest;
import com.forest.ds.user.service.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author 29002
 * @since 2024/6/18 下午8:01
 */
@RestController
@RequiredArgsConstructor
@RequestMapping("/user")
public class AuthController {
    private final UserService userService;

    @PostMapping("/login")
    public Integer login(@RequestBody AuthLoginRequest request) {
        return userService.login(request);
    }

    @PostMapping("/register")
    public Integer register(@RequestBody UserRegisterRequest request) {
        return userService.register(request);
    }
}
