package com.forest.ds.user.config;

import com.forest.ds.common.core.BaseControllerAdvice;
import org.springframework.web.bind.annotation.RestControllerAdvice;

/**
 * @author 29002
 * @since 2024/6/18 下午8:44
 */
@RestControllerAdvice
public class ControllerAdvice extends BaseControllerAdvice {
}
