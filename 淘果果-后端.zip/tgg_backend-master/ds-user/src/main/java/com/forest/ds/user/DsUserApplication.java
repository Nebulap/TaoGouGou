package com.forest.ds.user;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;

@SpringBootApplication
@EntityScan(basePackages = "com.forest.ds.common.domain.entity")
public class DsUserApplication {

    public static void main(String[] args) {
        SpringApplication.run(DsUserApplication.class, args);
    }

}
