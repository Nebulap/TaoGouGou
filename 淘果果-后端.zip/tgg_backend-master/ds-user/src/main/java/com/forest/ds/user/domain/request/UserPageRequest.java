package com.forest.ds.user.domain.request;

import com.forest.ds.common.domain.request.CommonPageRequest;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @author 29002
 * @since 2024/6/13 下午4:21
 */
@EqualsAndHashCode(callSuper = true)
@Data
public class UserPageRequest extends CommonPageRequest {
    private Boolean gender = null;
    private String username = null;
}
