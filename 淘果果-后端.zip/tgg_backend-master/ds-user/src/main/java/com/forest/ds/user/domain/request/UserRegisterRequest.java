package com.forest.ds.user.domain.request;

import lombok.Data;

/**
 * @author 29002
 * @since 2024/6/18 下午8:04
 */
@Data
public class UserRegisterRequest {
    //TODO 验证,懒得弄
    private String username;
    private String password;
}
