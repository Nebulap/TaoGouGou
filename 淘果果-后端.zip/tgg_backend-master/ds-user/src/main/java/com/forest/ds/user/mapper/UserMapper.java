package com.forest.ds.user.mapper;



import com.forest.ds.user.domain.dto.UserPageDto;
import com.forest.ds.common.domain.entity.User;
import com.forest.ds.user.domain.request.UserRegisterRequest;
import org.mapstruct.Mapper;


/**
 * @author 29002
 * @since 2024/6/13 下午2:34
 */
@Mapper(componentModel = "spring")
public interface UserMapper {
    UserPageDto ToUserPageDto(User user);
    User ToUser(UserRegisterRequest request);
}
