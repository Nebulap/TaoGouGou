package com.forest.ds.user.service.impl;

import com.forest.ds.common.core.CustomException;
import com.forest.ds.common.core.PageResponse;
import com.forest.ds.common.enums.ExceptionEnum;
import com.forest.ds.user.domain.dto.UserPageDto;
import com.forest.ds.common.domain.entity.AddressListCountInfo;
import com.forest.ds.common.domain.entity.User;
import com.forest.ds.user.domain.dto.UserTotalDto;
import com.forest.ds.user.domain.request.AuthLoginRequest;
import com.forest.ds.user.domain.request.UserPageRequest;
import com.forest.ds.user.domain.request.UserRegisterRequest;
import com.forest.ds.user.domain.request.UserRegisterStatsRequest;
import com.forest.ds.user.mapper.UserMapper;
import com.forest.ds.user.repository.AddressListRepository;
import com.forest.ds.user.repository.UserRepository;
import com.forest.ds.user.service.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.List;

import static com.forest.ds.user.domain.spec.UserSpecification.getPageSpecification;

/**
 * @author 29002
 * @since 2024/6/13 下午2:25
 */
@Service
@RequiredArgsConstructor
public class UserServiceImpl implements UserService {
    private final UserRepository userRepository;
    private final AddressListRepository addressListRepository;
    private final UserMapper userMapper;

    @Override
    public PageResponse page(UserPageRequest request) {
        Pageable pageable = request.buildPageable();
        Specification<User> spec = getPageSpecification(request);
        Page<User> users = userRepository.findAll(spec, pageable);
        int totalPages = users.getTotalPages();
        List<UserPageDto> userPageDtos = users.getContent().stream().map(userMapper::ToUserPageDto).toList();
        return PageResponse.of(userPageDtos, totalPages);
    }

    @Override
    public List<AddressListCountInfo> countUserAddress() {
        return addressListRepository.countAddressList();
    }

    @Override
    public UserTotalDto countUserTotal(UserRegisterStatsRequest request) {
        BigDecimal lastMonthRegisterUser = userRepository.getMonthUserTotal(request.getComparedMonth());
        BigDecimal currentMonthProfit = userRepository.getMonthUserTotal(request.getMonth());
        long total = userRepository.count();

        BigDecimal increasePercentage = BigDecimal.ZERO;
        if (lastMonthRegisterUser != null && lastMonthRegisterUser.compareTo(BigDecimal.ZERO) != 0) {
            increasePercentage = currentMonthProfit.subtract(lastMonthRegisterUser)
                    .divide(lastMonthRegisterUser, 2, RoundingMode.HALF_UP)
                    .multiply(new BigDecimal(100));
        }

        return new UserTotalDto((int) total, increasePercentage);
    }

    @Override
    public Integer login(AuthLoginRequest request) {
        User user = userRepository.getUserByUsername(request.getUsername());
        if (user == null) {
            throw new CustomException(ExceptionEnum.USER_PASSWORD_OR_USERNAME_ERROR);
        }
        if (!user.getPassword().equals(request.getPassword())) {
            throw new CustomException(ExceptionEnum.USER_PASSWORD_OR_USERNAME_ERROR);
        }
        return user.getId();
    }

    @Override
    public Integer register(UserRegisterRequest request) {
        boolean passwordNull = request.getPassword() == null || request.getPassword().isEmpty();
        boolean usernameNull = request.getUsername() == null || request.getUsername().isEmpty();
        if (passwordNull || usernameNull) {
            throw new CustomException(ExceptionEnum.REGISTER_USERNAME_OR_PASSWORD_NULL);
        }
        User dbUser = userRepository.getUserByUsername(request.getUsername());
        if (dbUser != null) {
            throw new CustomException(ExceptionEnum.USER_EXIST);
        }
        User user = userMapper.ToUser(request);
        User saved = userRepository.save(user);
        return saved.getId();
    }


}
