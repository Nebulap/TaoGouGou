package com.forest.ds.user.domain.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.math.BigDecimal;

/**
 * @author 29002
 * @since 2024/6/16 上午12:34
 */
@AllArgsConstructor
@Data
public class UserTotalDto {
    private Integer total;
    private BigDecimal difference;
}
