package com.forest.ds.user.service;

import com.forest.ds.common.core.PageResponse;
import com.forest.ds.common.domain.entity.AddressListCountInfo;
import com.forest.ds.user.domain.dto.UserTotalDto;
import com.forest.ds.user.domain.request.AuthLoginRequest;
import com.forest.ds.user.domain.request.UserPageRequest;
import com.forest.ds.user.domain.request.UserRegisterRequest;
import com.forest.ds.user.domain.request.UserRegisterStatsRequest;

import java.util.List;

/**
 * @author 29002
 * @since 2024/6/13 下午2:25
 */
public interface UserService {
    PageResponse page(UserPageRequest request);
    List<AddressListCountInfo> countUserAddress();
    UserTotalDto countUserTotal(UserRegisterStatsRequest request);


    Integer login(AuthLoginRequest request);
    Integer register(UserRegisterRequest request);
}
