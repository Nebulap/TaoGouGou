package com.forest.ds.user.repository;

import com.forest.ds.common.domain.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.math.BigDecimal;

public interface UserRepository extends JpaRepository<User, Integer>, JpaSpecificationExecutor<User> {

    @Query("SELECT count(*) FROM User WHERE  MONTH(createdAt) = :month")
    BigDecimal getMonthUserTotal(@Param("month") Integer month);

    User getUserByUsername(String username);
}
