package com.forest.ds.user.domain.request;

import lombok.Data;

/**
 * @author 29002
 * @since 2024/6/18 下午8:02
 */
@Data
public class AuthLoginRequest {
    private String username;
    private String password;
}
