package com.forest.ds.user.controller;

import com.forest.ds.common.core.PageResponse;
import com.forest.ds.common.domain.entity.AddressListCountInfo;
import com.forest.ds.user.domain.dto.UserTotalDto;
import com.forest.ds.user.domain.request.UserPageRequest;
import com.forest.ds.user.domain.request.UserRegisterStatsRequest;
import com.forest.ds.user.service.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * @author 29002
 * @since 2024/6/13 下午12:45
 */
@RestController
@RequestMapping("/user")
@RequiredArgsConstructor
public class UserController {
    private final UserService userService;

    @GetMapping
    public PageResponse page(UserPageRequest request) {
        return userService.page(request);
    }

    @GetMapping("/countAddress")
    public List<AddressListCountInfo> countInfos() {
        return userService.countUserAddress();
    }

    @GetMapping("/statsUserNumber")
    public UserTotalDto statsUserNumber(UserRegisterStatsRequest request) {
        return userService.countUserTotal(request);
    }
}
