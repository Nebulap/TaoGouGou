package com.forest.ds.user.domain.dto;

import com.forest.ds.common.domain.entity.User;
import lombok.Data;

import java.io.Serializable;
import java.time.Instant;

/**
 * DTO for {@link User}
 */
@Data
public class UserPageDto implements Serializable {
    private Integer id;
    private String username;
    private String nickname;
    private String phone;
    private Instant createdAt;
    private Boolean gender;
}
