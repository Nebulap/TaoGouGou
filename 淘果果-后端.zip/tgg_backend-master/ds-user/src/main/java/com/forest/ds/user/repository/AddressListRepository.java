package com.forest.ds.user.repository;

import com.forest.ds.common.domain.entity.AddressList;
import com.forest.ds.common.domain.entity.AddressListCountInfo;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface AddressListRepository extends JpaRepository<AddressList, Integer>, JpaSpecificationExecutor<AddressList> {
    @Query("SELECT a.state as name,COUNT(*) AS value  from AddressList a group by a.state")
    List<AddressListCountInfo> countAddressList();
}
