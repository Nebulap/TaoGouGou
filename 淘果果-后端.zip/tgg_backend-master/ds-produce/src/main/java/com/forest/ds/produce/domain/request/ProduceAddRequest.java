package com.forest.ds.produce.domain.request;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * DTO for {@link com.forest.ds.common.domain.entity.AgriculturalProduct}
 */
@Getter
@Setter
public class ProduceAddRequest implements Serializable {
    private String img;
    private String productName;
    private String category;
    private BigDecimal price;
    private BigDecimal specialPrice;
    private Integer quantity;
    private String farmLocation;
    private Long harvestDate;
    private Integer shelfLifeDays;
    private Boolean organic = false;
    private Integer purchasePrice;
    private Integer hideProfit = 0;
    private Instant createdAt = Instant.now();
}
