package com.forest.ds.produce.domain.dto;

import lombok.Data;

/**
 * @author 29002
 * @since 2024/6/15 下午1:23
 */
@Data
public class ProducePageDto {
}
