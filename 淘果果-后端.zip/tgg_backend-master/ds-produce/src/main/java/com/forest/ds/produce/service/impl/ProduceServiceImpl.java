package com.forest.ds.produce.service.impl;

import com.forest.ds.common.core.PageResponse;
import com.forest.ds.common.domain.entity.AgriculturalProduct;
import com.forest.ds.produce.domain.dto.ProduceCardDto;
import com.forest.ds.produce.domain.dto.ProduceCategoryStatsDto;
import com.forest.ds.produce.domain.request.*;
import com.forest.ds.produce.domain.spec.ProduceSpecification;
import com.forest.ds.produce.mapper.AgriculturalProductMapper;
import com.forest.ds.produce.repository.AgriculturalProductRepository;
import com.forest.ds.produce.service.ProduceService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @author 29002
 * @since 2024/6/15 下午1:16
 */
@Service
@RequiredArgsConstructor
public class ProduceServiceImpl implements ProduceService {
    private final AgriculturalProductRepository productRepository;
    private final ProduceSpecification produceSpecification;
    private final AgriculturalProductMapper agriculturalProductMapper;

    @Override
    public PageResponse page(ProducePageRequest request) {
        Pageable pageable = request.buildPageable();
        Specification<AgriculturalProduct> specification = produceSpecification.getCustomQuerySpecification(request);
        Page<AgriculturalProduct> products = productRepository.findAll(specification, pageable);
        return PageResponse.of(products.getContent(), products.getTotalPages());
    }

    @Override
    public List<ProduceCardDto> getProduceRanking() {
        Pageable pageable = PageRequest.of(0, 8);
        return productRepository.getProduceRanking(pageable);
    }

    @Override
    public AgriculturalProduct getById(Integer id) {
        return productRepository.getAgriculturalProductById(id);
    }

    @Override
    public void save(ProduceAddRequest request) {
        AgriculturalProduct agriculturalProduct = agriculturalProductMapper.partialAdd(request);
        productRepository.save(agriculturalProduct);
    }

    @Override
    public void update(ProduceUpdateRequest request) {
        AgriculturalProduct agriculturalProduct = agriculturalProductMapper.partialUpdate(request);
        productRepository.save(agriculturalProduct);
    }

    @Override
    public void delete(ProduceDeleteRequest request) {
        productRepository.deleteById(request.getId());
    }

    @Override
    public PageResponse getShopProduce(ProduceShopPageRequest request) {
        Pageable pageable = request.buildPageable();
        Specification<AgriculturalProduct> specification = produceSpecification.getShopPageSpecification(request);
        Page<AgriculturalProduct> productPage = productRepository.findAll(specification, pageable);
        return PageResponse.of(productPage.getContent(), productPage.getTotalPages());
    }

    @Override
    public List<ProduceCategoryStatsDto> categoryStats() {
        return productRepository.categoryStats();
    }
}
