package com.forest.ds.produce.controller;

import com.forest.ds.common.core.PageResponse;
import com.forest.ds.common.domain.entity.AgriculturalProduct;
import com.forest.ds.produce.domain.dto.ProduceCardDto;
import com.forest.ds.produce.domain.dto.ProduceCategoryStatsDto;
import com.forest.ds.produce.domain.request.*;
import com.forest.ds.produce.service.ProduceService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * @author 29002
 * @since 2024/6/15 下午1:36
 */
@RestController
@RequestMapping("/produce")
@RequiredArgsConstructor
public class ProduceController {
    private final ProduceService produceService;

    @PostMapping("/page")
    public PageResponse page(@RequestBody ProducePageRequest request) {
        return produceService.page(request);
    }

    @GetMapping("/getProduceRanking")
    public List<ProduceCardDto> getProduceRanking() {
        return produceService.getProduceRanking();
    }

    @PostMapping("/getShopProduce")
    public PageResponse getShopProduce(@RequestBody ProduceShopPageRequest request) {
        return produceService.getShopProduce(request);
    }

    @GetMapping("/{id}")
    public AgriculturalProduct getById(@PathVariable("id") Integer id) {
        return produceService.getById(id);
    }

    @DeleteMapping
    public void delete(ProduceDeleteRequest request) {
        produceService.delete(request);
    }

    @PostMapping
    public void add(@RequestBody ProduceAddRequest request) {
        produceService.save(request);
    }

    @PutMapping
    public void update(@RequestBody ProduceUpdateRequest request) {
        produceService.update(request);
    }

    @GetMapping("/categoryStats")
    public List<ProduceCategoryStatsDto> categoryStats() {
        return produceService.categoryStats();
    }
}
