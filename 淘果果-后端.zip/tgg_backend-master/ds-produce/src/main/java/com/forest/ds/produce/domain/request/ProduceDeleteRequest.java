package com.forest.ds.produce.domain.request;

import com.forest.ds.common.core.CustomQueryItem;
import lombok.Getter;
import lombok.Setter;

/**
 * @author 29002
 * @since 2024/6/19 下午7:02
 */
@Getter
@Setter
public class ProduceDeleteRequest {
    private Integer id;
}
