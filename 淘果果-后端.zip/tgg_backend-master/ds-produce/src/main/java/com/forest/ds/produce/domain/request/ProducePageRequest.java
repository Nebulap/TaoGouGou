package com.forest.ds.produce.domain.request;

import com.forest.ds.common.domain.request.CommonPageRequest;

/**
 * @author 29002
 * @since 2024/6/15 下午1:25
 */
public class ProducePageRequest extends CommonPageRequest {
}
