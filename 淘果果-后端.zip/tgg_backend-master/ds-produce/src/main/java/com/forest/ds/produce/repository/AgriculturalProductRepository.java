package com.forest.ds.produce.repository;

import com.forest.ds.common.domain.entity.AgriculturalProduct;
import com.forest.ds.produce.domain.dto.ProduceCardDto;
import com.forest.ds.produce.domain.dto.ProduceCategoryStatsDto;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface AgriculturalProductRepository extends JpaRepository<AgriculturalProduct, Integer>, JpaSpecificationExecutor<AgriculturalProduct> {
    @Query("SELECT SUM(ol.number) AS total_number, ap.productName as productName, ap.id as id,ap.price as price,ap.specialPrice as specialPrice,ap.img as img " +
            "FROM OrderProduceList ol " +
            "JOIN AgriculturalProduct ap ON ap.id = ol.produce.id " +
            "GROUP BY ap.productName, ap.id,ap.price,ap.specialPrice,ap.img " +
            "ORDER BY total_number DESC")
    List<ProduceCardDto> getProduceRanking(Pageable pageable);

    AgriculturalProduct getAgriculturalProductById(Integer id);

    @Query("SELECT category as name,count(*) as value FROM AgriculturalProduct " +
            "group by category " +
            "order by value desc ")
    List<ProduceCategoryStatsDto> categoryStats();
}
