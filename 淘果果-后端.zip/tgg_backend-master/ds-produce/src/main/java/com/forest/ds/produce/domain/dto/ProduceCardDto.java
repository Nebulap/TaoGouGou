package com.forest.ds.produce.domain.dto;

import lombok.Data;

import java.math.BigDecimal;

/**
 * @author 29002
 * @since 2024/6/19 上午9:32
 */
public interface ProduceCardDto {
    Integer getId();
    String getProductName();
    BigDecimal getPrice();
    String getImg();
    BigDecimal getSpecialPrice();
}
