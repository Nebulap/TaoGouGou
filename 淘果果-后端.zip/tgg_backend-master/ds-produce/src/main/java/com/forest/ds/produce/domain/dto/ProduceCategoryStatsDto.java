package com.forest.ds.produce.domain.dto;

/**
 * @author 29002
 * @since 2024/6/21 下午4:34
 */
public interface ProduceCategoryStatsDto {
    String getName();
    Integer getValue();
}
