package com.forest.ds.produce.domain.request;

import com.forest.ds.common.domain.request.CommonPageRequest;
import com.forest.ds.produce.enums.ProduceShopSort;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

/**
 * @author 29002
 * @since 2024/6/20 下午2:50
 */
@Getter
@Setter
public class ProduceShopPageRequest extends CommonPageRequest {
    private List<String> categoryList = new ArrayList<>();
    private ProduceShopSort sort = ProduceShopSort.FRESH;
    private Integer max = 100;
    private Integer min = 1;
}
