package com.forest.ds.produce.service;

import com.forest.ds.common.core.PageResponse;
import com.forest.ds.common.domain.entity.AgriculturalProduct;
import com.forest.ds.produce.domain.dto.ProduceCardDto;
import com.forest.ds.produce.domain.dto.ProduceCategoryStatsDto;
import com.forest.ds.produce.domain.request.*;

import java.util.List;

/**
 * @author 29002
 * @since 2024/6/15 下午1:16
 */
public interface ProduceService {
    PageResponse page(ProducePageRequest request);
    List<ProduceCardDto> getProduceRanking();
    AgriculturalProduct getById(Integer id);
    void save(ProduceAddRequest request);
    void update(ProduceUpdateRequest request);
    void delete(ProduceDeleteRequest request);
    PageResponse getShopProduce(ProduceShopPageRequest request);
    List<ProduceCategoryStatsDto> categoryStats();
}
