package com.forest.ds.produce.mapper;

import com.forest.ds.common.domain.entity.AgriculturalProduct;
import com.forest.ds.produce.domain.request.ProduceAddRequest;
import com.forest.ds.produce.domain.request.ProduceUpdateRequest;
import org.mapstruct.*;

@Mapper(unmappedTargetPolicy = ReportingPolicy.IGNORE, componentModel = MappingConstants.ComponentModel.SPRING)
public interface AgriculturalProductMapper {
    AgriculturalProduct toEntity(ProduceAddRequest produceAddRequest);
    ProduceAddRequest toDto(AgriculturalProduct agriculturalProduct);
    AgriculturalProduct partialUpdate(ProduceUpdateRequest produceUpdateRequest);
    AgriculturalProduct partialAdd(ProduceAddRequest produceAddRequest);
}
