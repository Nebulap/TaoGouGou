package com.forest.ds.produce.enums;

import lombok.Getter;

/**
 * @author 29002
 * @since 2024/6/20 下午2:53
 */
@Getter
public enum ProduceShopSort {
    FRESH("新鲜度"),
    NAME("按名称");


    private final String name;

    ProduceShopSort(String name) {
        this.name = name;
    }
}
