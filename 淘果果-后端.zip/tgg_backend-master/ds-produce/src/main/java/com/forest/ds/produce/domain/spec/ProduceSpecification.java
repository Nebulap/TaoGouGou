package com.forest.ds.produce.domain.spec;

import com.forest.ds.common.core.BaseSpecification;
import com.forest.ds.common.domain.entity.AgriculturalProduct;
import com.forest.ds.produce.domain.request.ProduceShopPageRequest;
import jakarta.persistence.criteria.Predicate;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

/**
 * @author 29002
 * @since 2024/6/15 下午1:30
 */
@Component
public class ProduceSpecification extends BaseSpecification<AgriculturalProduct> {


    public Specification<AgriculturalProduct> getShopPageSpecification(ProduceShopPageRequest request) {
        return (root, query, criteriaBuilder) -> {
            List<Predicate> predicates = new ArrayList<>();

            // 添加分类条件
            if (!request.getCategoryList().isEmpty()) {
                if (request.getCategoryList().stream().noneMatch("全部"::equals)) {
                    predicates.add(root.get("category").in(request.getCategoryList()));
                }
            } else {
                predicates.add(criteriaBuilder.equal(root.get("category"),"无"));
            }

            // 添加价格范围条件
            predicates.add(criteriaBuilder.or(
                    criteriaBuilder.between(
                            criteriaBuilder.coalesce(root.get("specialPrice"), root.get("price")),
                            request.getMin(), request.getMax()
                    ))
            );

            // 添加排序条件
            switch (request.getSort()) {
                case NAME:
                    query.orderBy(criteriaBuilder.asc(root.get("productName")));
                    break;
                case FRESH:
                    query.orderBy(criteriaBuilder.desc(root.get("harvestDate")));
                    break;
                default:
                    query.orderBy(criteriaBuilder.asc(root.get("id"))); // 默认按ID升序
                    break;
            }

            return criteriaBuilder.and(predicates.toArray(new Predicate[0]));
        };
    }

}
