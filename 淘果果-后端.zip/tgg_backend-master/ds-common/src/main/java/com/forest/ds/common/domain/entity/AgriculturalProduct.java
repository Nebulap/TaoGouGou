package com.forest.ds.common.domain.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.ColumnDefault;
import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import java.math.BigDecimal;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.LinkedHashSet;
import java.util.Set;

@Getter
@Setter
@Entity
@Table(name = "agricultural_products")
@DynamicInsert
@DynamicUpdate
public class AgriculturalProduct {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    private Integer id;
    @Column(name = "img")
    private String img;

    @Column(name = "product_name", nullable = false)
    private String productName;

    @Column(name = "category", nullable = false)
    private String category;

    @Column(name = "price", nullable = false, precision = 10, scale = 2)
    private BigDecimal price;

    @Column(name = "special_price", precision = 10, scale = 2)
    private BigDecimal specialPrice;

    @Column(name = "quantity", nullable = false)
    private Integer quantity;

    @Column(name = "farm_location", nullable = false)
    private String farmLocation;

    @Column(name = "harvest_date", nullable = false)
    private Long harvestDate;

    @Column(name = "shelf_life_days", nullable = false)
    private Integer shelfLifeDays;

    @Column(name = "organic", nullable = false)
    private Boolean organic = false;

    @Column(name = "purchase_price", nullable = false)
    private Integer purchasePrice;


    @Column(name = "hide_profit", nullable = false)
    private Integer hideProfit;

    @ColumnDefault("CURRENT_TIMESTAMP")
    @Column(name = "created_at")
    private Instant createdAt;

}
