package com.forest.ds.common.core;

import com.forest.ds.common.enums.ComparisonEnum;
import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Predicate;
import jakarta.persistence.criteria.Root;
import lombok.Data;

/**
 * @author 29002
 * @since 2024/6/14 下午9:36
 */
@Data
public class CustomQueryItem<T extends Comparable<T>> {
    private String name;
    private ComparisonEnum comparison;
    private T value;

    public Predicate toPredicate(Root<?> root, CriteriaQuery<?> query, CriteriaBuilder criteriaBuilder) {
        return switch (comparison) {
            case EQ -> criteriaBuilder.equal(root.get(name), value);
            case GT -> criteriaBuilder.greaterThan(root.get(name), value);
            case GE -> criteriaBuilder.greaterThanOrEqualTo(root.get(name), value);
            case LT -> criteriaBuilder.lessThan(root.get(name), value);
            case LE -> criteriaBuilder.lessThanOrEqualTo(root.get(name), value);
            case NQ -> criteriaBuilder.notEqual(root.get(name), value);
            case LIKE -> criteriaBuilder.like((root).get(name), "%" + value.toString() + "%");
            default -> throw new IllegalArgumentException("Unsupported comparison operator: " + comparison);
        };
    }
}
