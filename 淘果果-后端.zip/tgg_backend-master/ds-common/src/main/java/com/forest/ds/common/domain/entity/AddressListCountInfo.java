package com.forest.ds.common.domain.entity;

/**
 * Projection for {@link AddressList}
 */
public interface AddressListCountInfo {
    String getName();
    Integer getValue();
}
