package com.forest.ds.common.core;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;

import java.util.List;

/**
 * @author 29002
 * @since 2024/6/13 下午2:27
 */
@Data
@AllArgsConstructor
public class PageResponse {
    private Object pageData;
    private int totalPages;


    public static PageResponse of(Object pageData, int totalPages) {
        return new PageResponse(pageData, totalPages);
    }
}
