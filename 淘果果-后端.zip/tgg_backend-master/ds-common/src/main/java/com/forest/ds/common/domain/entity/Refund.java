package com.forest.ds.common.domain.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.ColumnDefault;
import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import java.math.BigDecimal;
import java.time.Instant;

@Getter
@Setter
@Entity
@Table(name = "refunds")
@DynamicInsert
@DynamicUpdate
public class Refund {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "refund_id", nullable = false)
    private Integer id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "order_id", nullable = false)
    private Order order;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "customer_id", nullable = false)
    private User customer;

    @Column(name = "refund_amount", nullable = false, precision = 10, scale = 2)
    private BigDecimal refundAmount;

    @Column(name = "refund_reason")
    private String refundReason;

    @ColumnDefault("'PENDING'")
    @Lob
    @Column(name = "refund_status")
    private String refundStatus;

    @ColumnDefault("CURRENT_TIMESTAMP")
    @Column(name = "request_date")
    private Instant requestDate;

    @Column(name = "processed_date")
    private Instant processedDate;

    @Lob
    @Column(name = "remarks")
    private String remarks;

}
