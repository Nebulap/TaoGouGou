package com.forest.ds.common.enums;

import lombok.Getter;

@Getter
public enum TimeRange {
    LAST_7_DAYS("最近7天"),
    LAST_30_DAYS("最近30天"),
    THIS_YEAR_BY_MONTH("今年(月份)"),
    THIS_YEAR_BY_QUARTER("今年(季度)");

    private final String label;

    TimeRange(String label) {
        this.label = label;
    }

}
