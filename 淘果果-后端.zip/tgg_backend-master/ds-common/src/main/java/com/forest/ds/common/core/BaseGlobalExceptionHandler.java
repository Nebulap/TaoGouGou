package com.forest.ds.common.core;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.web.bind.annotation.ExceptionHandler;

/**
 * @author 29002
 * @since 2024/6/18 下午8:20
 */
public class BaseGlobalExceptionHandler {

    @ExceptionHandler(CustomException.class)
    public Result customException(CustomException e) {
        return Result.fail(e);
    }


    @ExceptionHandler(Exception.class)
    public Result exception(Exception e) {
        return Result.fail(new CustomException(e.getMessage()));
    }


}
