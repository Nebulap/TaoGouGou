package com.forest.ds.common.domain.request;

import lombok.Getter;
import lombok.Setter;
import org.springframework.data.domain.Pageable;

/**
 * @author 29002
 * @since 2024/6/13 下午2:26
 */
@Getter
@Setter
public class CommonPageRequest extends CommonQueryRequest {
    private Integer pageNum = 0;
    private Integer pageSize = 10;

    public Pageable buildPageable() {
        return org.springframework.data.domain.PageRequest.of(pageNum, pageSize);
    }
}
