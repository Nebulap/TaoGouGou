package com.forest.ds.common.enums;

import lombok.Getter;

/**
 * @author 29002
 * @since 2024/6/18 下午8:21
 */
@Getter
public enum ExceptionEnum {
    UNKNOWN("未知异常", 0),
    //认证异常
    USER_NOT_LOGIN("用户未登录", 10001),
    USER_PASSWORD_OR_USERNAME_ERROR("用户名或密码错误", 10002),
    USER_NOT_EXIST("用户不存在", 10003),
    USER_EXIST("用户存在", 10004),
    REGISTER_USERNAME_OR_PASSWORD_NULL("注册信息缺失",10005)

    //订单异常
    ;

    private final String msg;
    private final int code;

    ExceptionEnum(String msg, int code) {
        this.msg = msg;
        this.code = code;
    }
}
