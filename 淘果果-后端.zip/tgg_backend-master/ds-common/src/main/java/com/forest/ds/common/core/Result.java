package com.forest.ds.common.core;

import com.forest.ds.common.enums.ExceptionEnum;
import lombok.Data;

/**
 * @author 29002
 * @since 2024/6/18 下午8:05
 */
@Data
public class Result {
    private int code;
    private String msg;
    private Object data;


    public Result(int code, String msg, Object data) {
        this.code = code;
        this.msg = msg;
        this.data = data;
    }

    public static Result success(Object data) {
        return new Result(100, "success", data);
    }

    public static Result fail(int code, String msg) {
        return new Result(code, msg, null);
    }

    public static Result fail(CustomException exception) {
        ExceptionEnum exceptionEnum = exception.getExceptionEnum();
        if (exceptionEnum == ExceptionEnum.UNKNOWN) {
            return Result.fail(exceptionEnum.getCode(), exception.getMessage());
        }
        return Result.fail(exceptionEnum.getCode(), exceptionEnum.getMsg());
    }
}
