package com.forest.ds.common.enums;

import lombok.Getter;

/**
 * @author 29002
 * @since 2024/6/14 下午9:32
 */
@Getter
public enum ComparisonEnum {
    EQ("相等", 0),
    NQ("不相等", 1),
    GT("大于", 2),
    GE("大于或等于", 3),
    LT("小于", 4),
    LE("小于或等等于", 5),
    LIKE("模糊查询",6);


    private final String name;
    private final int code;

    ComparisonEnum(String name, int code) {
        this.name = name;
        this.code = code;
    }
}
