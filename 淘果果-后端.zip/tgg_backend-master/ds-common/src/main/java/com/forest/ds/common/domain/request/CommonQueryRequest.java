package com.forest.ds.common.domain.request;

import com.forest.ds.common.core.CustomQueryItem;
import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

/**
 * @author 29002
 * @since 2024/6/14 下午9:52
 */
@Getter
@Setter
public class CommonQueryRequest {
    private List<CustomQueryItem<Integer>> customIntegerQueryItems = new ArrayList<>();
    private List<CustomQueryItem<String>> customStringQueryItems = new ArrayList<>();
}
