package com.forest.ds.common.core;

import com.forest.ds.common.enums.ExceptionEnum;
import lombok.Getter;

/**
 * @author 29002
 * @since 2024/6/18 下午8:20
 */
@Getter
public class CustomException extends RuntimeException {
    private ExceptionEnum exceptionEnum = ExceptionEnum.UNKNOWN ;

    public CustomException(ExceptionEnum exceptionEnum) {
        this.exceptionEnum = exceptionEnum;
    }

    public CustomException(String message) {
        super(message);
    }
}
