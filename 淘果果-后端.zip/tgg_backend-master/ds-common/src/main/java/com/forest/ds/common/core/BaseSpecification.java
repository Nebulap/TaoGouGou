package com.forest.ds.common.core;


import com.forest.ds.common.domain.request.CommonQueryRequest;
import jakarta.persistence.criteria.Predicate;
import org.springframework.data.jpa.domain.Specification;

import java.util.ArrayList;
import java.util.List;


/**
 * @author 29002
 * @since 2024/6/14 下午9:49
 */
public class BaseSpecification<T> {

    public Specification<T> getCustomQuerySpecification(CommonQueryRequest request) {
        return getCustomQuerySpecification(null, request);
    }

    public Specification<T> getCustomQuerySpecification(Specification<T> specification, CommonQueryRequest request) {
        return (root, query, criteriaBuilder) -> {
            List<Predicate> predicates = new ArrayList<>();

            if (!request.getCustomIntegerQueryItems().isEmpty()) {
                request.getCustomIntegerQueryItems().stream()
                        .filter(item -> item.getValue() != null)
                        .forEach(item -> predicates.add(item.toPredicate(root, query, criteriaBuilder)));
            }

            if (!request.getCustomStringQueryItems().isEmpty()) {
                request.getCustomStringQueryItems().stream()
                        .filter(item -> item.getValue() != null && !item.getValue().isEmpty())
                        .forEach(item -> predicates.add(item.toPredicate(root, query, criteriaBuilder)));
            }

            Predicate customPredicate = criteriaBuilder.and(predicates.toArray(new Predicate[0]));

            if (specification != null) {
                return criteriaBuilder.and(specification.toPredicate(root, query, criteriaBuilder), customPredicate);
            } else {
                return customPredicate;
            }
        };
    }


}
