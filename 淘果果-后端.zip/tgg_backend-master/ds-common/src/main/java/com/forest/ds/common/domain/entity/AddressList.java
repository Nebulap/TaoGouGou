package com.forest.ds.common.domain.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "address_list")
public class AddressList {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    private Integer id;

    @Column(name = "state")
    private String state;

    @Column(name = "city")
    private String city;

    @Column(name = "county")
    private String county;

    @Column(name = "detail")
    private Integer detail;

    @Column(name = "phone")
    private Integer phone;

    @Column(name = "recipient_name")
    private String recipientName;

    @Column(name = "recipient_id")
    private Integer recipientId;

}
