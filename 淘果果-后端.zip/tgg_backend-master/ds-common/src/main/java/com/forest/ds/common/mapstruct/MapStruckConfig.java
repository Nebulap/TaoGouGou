package com.forest.ds.common.mapstruct;

/**
 * @author 29002
 * @since 2024/6/13 下午2:33
 */
public class MapStruckConfig {
    public static final String MODEL = "spring";
}
