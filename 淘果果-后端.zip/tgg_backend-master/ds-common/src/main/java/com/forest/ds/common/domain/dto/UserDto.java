package com.forest.ds.common.domain.dto;

import jakarta.persistence.Column;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import org.hibernate.annotations.ColumnDefault;

import java.time.Instant;

/**
 * @author 29002
 * @since 2024/6/16 上午12:57
 */
public class UserDto {
    private Integer id;
    private String username;
    private String nickname;
    private String phone;
    private Instant createdAt;
    private String avatar;
    private Boolean gender;
}
