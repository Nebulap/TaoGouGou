import { defineConfig, presetUno } from "unocss";
import presetIcons from "@unocss/preset-icons";

export default defineConfig({
  rules: [["card", {'box-shadow':'0 0 20px rgba(0, 0, 0, .1)'}]],
  presets: [presetUno(), presetIcons()],
  content: {
    pipeline: {
      include: [
        "src/router/index.js",
        /\.(vue|svelte|[jt]sx|mdx?|astro|elm|php|phtml|html)($|\?)/,
      ],
    },
  },
});
