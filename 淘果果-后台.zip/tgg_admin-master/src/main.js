import { createApp } from 'vue'
import 'normalize/lib/normalize/base/index.styl'
import App from './App.vue'
import 'uno.css'
import './assets/style.css'

import router from './router'
import Naive from 'naive-ui'
import {createPinia} from "pinia";
const pinia = createPinia()
import "./utils/index.js"

createApp(App).use(router).use(pinia).use(Naive).mount('#app')
