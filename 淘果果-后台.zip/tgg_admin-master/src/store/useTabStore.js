import { defineStore } from "pinia";
import { ref, watch } from "vue";
import { message } from "../utils/index.js";
import { useRoute, useRouter } from "vue-router";

export const useTabStore = defineStore("tab", () => {
  const router = useRouter();
  const route = useRoute();

  const state = ref({
    tabs: [
      {
        name: "home",
        label: "首页",
      },
      {
        name: "userList",
        label: "用户列表",
      },
    ],

    currentTab: "",
  });

  const stop = watch(route, () => {
    addTab({ name: route.name, label: route.meta['label'] });
    sideMenuRef.value.showOption(route.name);
    stop();
  });

  let sideMenuRef = ref(null);
  function setSideMenuRef(ref) {
    sideMenuRef = ref;
  }

  function getSideMenuRef() {
    return sideMenuRef;
  }

  function addTab(tab) {
    if (!state.value.tabs.find((item) => item.name === tab.name)) {
      state.value.tabs.push(tab);
    }
    state.value.currentTab = tab.name;
  }

  function handleClose(tabName) {
    if (state.value.tabs.length === 1) {
      message.info("最后一个了QAQ");
      return;
    }
    const index = state.value.tabs.findIndex((item) => item.name === tabName);
    state.value.tabs = state.value.tabs.filter((tab) => tab.name !== tabName);
    const tab = state.value.tabs[index];
    //优先选中右侧,其次左侧
    state.value.currentTab = (tab ?? state.value.tabs[index - 1]).name;
    selectTab(state.value.currentTab)
  }

  async function selectTab(tabName) {
    await router.push({ name: tabName });
    sideMenuRef.value.showOption(tabName);
  }

  return {
    state,
    selectTab,
    addTab,
    handleClose,
    getSideMenuRef,
    setSideMenuRef,
  };
});
