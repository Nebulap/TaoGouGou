import { defineStore } from "pinia";
import { ref } from "vue";

export const useAppStore = defineStore("app", () => {
  const state = ref({
    sideBar: {
      folded: false,
    },
    header:{
      title:""
    },
    layout: {
      headerHeight: 80,
      sideBarWidth: 240,
    },
  });


  return { state };
});
