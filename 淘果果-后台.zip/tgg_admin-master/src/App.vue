<script setup>
import { RouterView } from "vue-router";
import PublicLayout from "./layout/PublicLayout.vue";

import { zhCN, dateZhCN } from "naive-ui";
</script>

<template>
  <NConfigProvider :locale="zhCN" :date-locale="dateZhCN">
    <NMessageProvider>
      <NModalProvider>
        <PublicLayout>
          <router-view />
        </PublicLayout>
      </NModalProvider>
    </NMessageProvider>
  </NConfigProvider>
</template>

<style scoped></style>
