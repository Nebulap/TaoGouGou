import { createRouter, createWebHistory } from "vue-router";

const routes = [
  {
    name: "home",
    path: "/",
    meta: {
      icon: "i-ri:mac-line",
      label: "首页",
      description: "查看系统的总览信息。",
    },
    component: () => import("../view/home/index.vue"),
  },
  {
    name: "dataAnalysis",
    path: "/data-analysis",
    component: () => import("../view/data-analysis/index.vue"),
    meta: {
      icon: "i-ri:line-chart-line",
      label: "数据分析",
      description: "配置系统的各种参数和设置，例如语言、主题、权限等。",
    },
  },
  {
    name: "farmProduceIndex",
    path: "/farm-produce-index",
    meta: {
      icon: "i-ri:apps-line",
      label: "农产品管理",
    },
    children: [
      {
        name: "farmProduceList",
        path: "/farm-produce/list",
        meta: {
          icon: "i-ri:stack-line",
          label: "农产品列表",
          description: "占位",
        },
        component: () => import("../view/farm-produce/list/index.vue"),
      },
    ],
  },
  {
    name: "order",
    path: "/order",
    meta: {
      icon: "i-ri:apps-line",
      label: "订单管理",
    },
    children: [
      {
        name: "orderList",
        path: "/order/list",
        meta: {
          icon: "i-ri:notification-2-line",
          label: "订单列表",
          description: "占位",
        },
        component: () => import("../view/order/list/index.vue"),
      },
      {
        name: "afterSales",
        path: "/order/after-sales",
        meta: {
          icon: "i-ri:file-close-line",
          label: "售后退款",
          description: "占位",
        },
        component: () => import("../view/farm-produce/index.vue"),
      },
    ],
  },

  {
    name: "user",
    path: "/user",
    meta: {
      icon: "i-ri:apps-line",
      label: "用户管理",
    },
    children: [
      {
        name: "userList",
        path: "/user/list",
        meta: {
          icon: "i-ri:group-line",
          label: "用户列表",
          description: "展示系统中所有用户的列表，并提供搜索和过滤功能。",
        },
        component: () => import("../view/user/list/index.vue"),
      },
    ],
  },
  {
    name: "settings",
    path: "/settings",
    component: () => import("../view/setting/index.vue"),
    meta: {
      icon: "i-ri:settings-2-line",
      label: "系统设置",
      description: "配置系统的各种参数和设置，例如语言、主题、权限等。",
    },
  },
];

const router = createRouter({
  routes,
  history: createWebHistory(),
});

export default router;
