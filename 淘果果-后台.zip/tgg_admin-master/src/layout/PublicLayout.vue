<script setup>
import { NLayout, NLayoutSider, NDivider, NMenu } from "naive-ui";
import TheHeader from "../components/app/TheHeader.vue";
import {toRefs} from "vue";
import { useAppStore } from "../store/useAppStore.js";
import TheTabs from "../components/app/TheTabs.vue";
import SideMenu from "../components/app/side-menu/SideMenu.vue";

const appStore = useAppStore();


const { headerHeight, sideBarWidth } = toRefs(appStore.state.layout);

</script>

<template>
  <n-layout>
    <n-layout has-sider>
      <n-layout-sider
        bordered
        collapse-mode="width"
        :collapsed-width="64"
        :width="sideBarWidth"
        :native-scrollbar="false"
        class="h-lvh"
        show-trigger
        v-model:collapsed="appStore.state.sideBar.folded"
      >
        <div
            class="text-2xl font-bold whitespace-nowrap !gap-0 flex justify-center items-center"
            :style="{ minHeight: headerHeight + 'px', display: 'flex', alignItems: 'center' }"
        >
          <div style="display: flex; align-items: center;">
            <div class="i-ri:supabase-line hover:text-3xl transition-all"></div>
            <span v-show="!appStore.state.sideBar.folded" class="ml-3">Simple Admin</span>
          </div>
        </div>

        <n-divider class="!m-0" />
        <SideMenu />
      </n-layout-sider>
      <n-layout />
      <div class="w-full h-lvh bg-[rgb(244,246,250)]">
        <TheHeader class="!h-[56px] " />
        <div class="!m-0 !bg-[rgb(239,239,245)] h-[1px]" />
        <TheTabs class="!min-h-[32px]" />
        <div class="max-h-[calc(100vh-125px)] overflow-y-auto">
          <slot />
          <div class="text-align-center text-gray-300">© 2024-2024 ForestAndForest. All Rights Reserved.</div>
        </div>
      </div>
    </n-layout>
  </n-layout>
</template>

<style scoped></style>
