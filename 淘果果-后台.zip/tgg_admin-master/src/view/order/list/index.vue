<script setup>
import DataForm from "../../../components/common/data-form/DataForm.vue";

import { getData, getOrderById, save } from "./api.js";
import { h, ref } from "vue";
import QueryItem from "../../../components/common/data-form/QueryItem.vue";
import { NButton, NEllipsis, NPopconfirm, NSpace, NTag } from "naive-ui";
import OrderForm from "./model/OrderForm.vue";
import { formatTimestamp } from "../../../utils/index.js";

const formRef = ref(null);
const dataForm = ref(null);
const queryModel = ref({
  productName: "",
  customerId: "",
  customIntegerQueryItems: [
    {
      name: "customerId",
      comparison: "EQ",
      value: "",
    },
  ],
  customStringQueryItems: [
    {
      name: "orderStatus",
      comparison: "EQ",
      value: "",
    },
    {
      name: "paymentMethod",
      comparison: "EQ",
      value: "",
    },
  ],
});

const columns = [
  {
    title: renderTitle("#"),
    width: 70,
    key: "id",
  },
  {
    title: renderTitle("客户ID"),
    width: 100,
    key: "customerId",
    render: (row) => {
      let newStr = row["customerId"].toString();
      if (queryModel.value.customerId !== "") {
        newStr = newStr.replace(
          queryModel.value.customerId.toString(),
          `<span class='text-red-500'>${queryModel.value.customerId}</span>`,
        );
      }
      return h("div", { innerHTML: newStr });
    },
  },
  // {
  //   title: renderTitle("产品名称"),
  //   width: 150,
  //   key: "product",
  //   render: (row) => {
  //     let newStr = row["product"]["productName"];
  //     return h("div", { innerHTML: newStr });
  //   },
  // },
  {
    title: renderTitle("数量"),
    width: 80,
    key: "quantity",
    render: (row) =>
      h(
        "span",
        row["products"].reduce((t, c) => t + c.number, 0),
      ),
  },
  {
    title: renderTitle("总价"),
    width: 90,
    key: "totalPrice",
    render: (row) => `¥${row["totalPrice"].toFixed(2)}`,
  },
  {
    title: renderTitle("订单状态"),
    key: "orderStatus",
    render: (row) => renderOrderStatus(row["orderStatus"]),
  },
  {
    title: renderTitle("下单时间"),
    width: 210,
    key: "orderDate",
  },
  {
    title: renderTitle("发货时间"),
    width: 210,
    key: "deliveryDate",
  },
  {
    title: renderTitle("送货地址"),
    width: 210,
    render: (row) =>
      h(NEllipsis, { class: "!max-w-[210px]" }, () => row["deliveryAddress"]),
    key: "deliveryAddress",
  },
  {
    title: renderTitle("支付方式"),
    key: "paymentMethod",
  },
  {
    title: renderTitle("操作"),
    key: "action",
    render: (row) =>
      h(NSpace, () => [
        h(
          NButton,
          {
            type: "info",
            size: "small",
            onClick: () => showForm("edit", row["id"]),
          },
          () => "查看",
        ),
        h(
          NButton,
          { type: "warning", size: "small", secondary: true },
          () => "加入售后退款",
        ),
      ]),
  },
];

const productColumns = [
  {
    title: renderTitle("#"),
    width: 70,
    key: "produce.id",
  },
  {
    title: renderTitle("产品名称"),
    width: 150,
    key: "produce.productName",
  },
  {
    title: renderTitle("分类"),
    width: 110,
    key: "produce.category",
  },
  {
    title: renderTitle("单价"),
    width: 100,
    render: (row) => `¥${(row["produce"]["price"]).toFixed(2)}`,
  },
  {
    title: renderTitle("数量"),
    width: 110,
    key: "number",
  },
  {
    title: renderTitle("价格"),
    width: 110,
    key: "produce.price",
    render: (row) => `¥${(row["produce"]["price"] * row["number"]).toFixed(2)}`,
  },
];

const paymentMethodOptions = [
  {
    label: "所有",
    value: "",
  },
  {
    label: "微信支付",
    value: "微信支付",
  },
  {
    label: "支付宝",
    value: "支付宝",
  },
  {
    label: "信用卡",
    value: "信用卡",
  },
  {
    label: "其他",
    value: "其他",
  },
];

const orderStatusOptions = [
  {
    label: "所有",
    value: "",
  },
  {
    label: "待发货",
    value: "待发货",
  },
  {
    label: "已发货",
    value: "已发货",
  },
  {
    label: "已取消",
    value: "已取消",
  },
  {
    label: "已完成",
    value: "已完成",
  },
];
const data = ref({});

function summary(pageData) {
  console.log(pageData);
  return {
    "produce.price": {
      value: h(
          "span",
          {class:"text-red-500 text-4"},
        `¥${pageData.reduce((p,c)=>p+c['produce']['price']*c['number'],0).toFixed(2)}`,
      ),
      colspan: 3,
    },
  };
}

async function showForm(active, id = 0) {
  if (active === "edit") {
    data.value = (await getOrderById(id)).data;
    data.value["harvestDate"] = new Date(data.value["harvestDate"]).getTime();
  } else if (active === "add") {
    data.value = {};
  }

  if (formRef.value) {
    formRef.value.openModal(active);
  }
}

function renderTitle(title) {
  return () => h("span", { class: "text-4 text-gray-600 font-bold" }, title);
}

function renderOrderStatus(status) {
  function _getType() {
    switch (status) {
      case "待发货":
        return "default";
      case "已完成":
        return "primary";
      case "已取消":
        return "warning";
      case "已发货":
        return "info";
    }
  }

  return h(NTag, { type: _getType() }, () => status);
}

const pagination = ref({
  pageSize: 8,
  page: 1,
});

function refreshData() {
  if (dataForm.value) {
    dataForm.value.refreshData();
  }
}
</script>

<template>
  <order-form
    ref="formRef"
    :data="data"
    v-slot="slotProps"
    :update-data="save"
    :refresh-data="refreshData"
  >
    <n-form label-align="right" :label-placement="'left'" :label-width="80">
      <n-form-item
        label="ID"
        v-if="['edit', 'view'].includes(slotProps.active)"
      >
        <n-input-number
          placeholder="id"
          disabled
          :show-button="false"
          v-model:value="data['id']"
        />
      </n-form-item>
      <n-form-item label="客户ID">
        <n-input-number
          placeholder="id"
          disabled
          :show-button="false"
          v-model:value="data['customerId']"
        />
      </n-form-item>
      <n-form-item label="订单内容">
        <n-data-table
          :columns="productColumns"
          :data="data['products']"
          remote
          :paginate-single-page="false"
          :summary="summary"
        />
      </n-form-item>
      <n-form-item label="订单状态">
        <n-select
          placeholder="订单状态"
          :options="orderStatusOptions.slice(1)"
          v-model:value="data['orderStatus']"
        />
      </n-form-item>
    </n-form>
  </order-form>
  <data-form
    :get-data="getData"
    v-model:query-model="queryModel"
    :pagination="pagination"
    :columns="columns"
    ref="dataForm"
  >
    <template #query>
      <query-item label="客户ID">
        <n-input
          v-model:value="queryModel.customIntegerQueryItems[0].value"
          placeholder="输入客户ID"
        />
      </query-item>
      <query-item label="订单状态">
        <n-select
          class="w-[120px]"
          default-value=""
          v-model:value="queryModel.customStringQueryItems[0].value"
          :options="orderStatusOptions"
        />
      </query-item>
      <query-item label="支付方式">
        <n-select
          class="w-[120px]"
          default-value=""
          v-model:value="queryModel.customStringQueryItems[1].value"
          :options="paymentMethodOptions"
        >
        </n-select>
      </query-item>
    </template>
  </data-form>
</template>

<style scoped></style>
