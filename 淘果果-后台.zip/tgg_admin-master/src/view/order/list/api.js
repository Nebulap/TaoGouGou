import {request} from "../../../utils/request.js";


export const getData = async (data)=>request.post("/api/order",data)
export const getOrderById = async (id)=>request.get("/api/order/id/"+id)
export const save = async (data)=>request.put("/api/order",data)

