import {request} from "../../../utils/request.js";


export const getData = async (params)=>request.get("/api/user",{params:params})
