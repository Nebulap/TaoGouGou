<script setup>
import DataForm from "../../../components/common/data-form/DataForm.vue";

import { getData } from "./api.js";
import { h, ref } from "vue";
import QueryItem from "../../../components/common/data-form/QueryItem.vue";
import { NButton, NSpace } from "naive-ui";

const queryModel = ref({
  username: "",
  gender:""
});

const columns = [
  {
    title: renderTitle("#"),
    width: 140,
    key: "id",
  },
  {
    title: renderTitle("用户名"),
    width: 200,
    key: "username",
    render: (row) => {
      let newStr = row["username"];
      if (queryModel.value.username !== "") {
        newStr = row["username"].replace(
          queryModel.value.username,
          `<span class='text-red-500'>${queryModel.value.username}</span>`,
        );
      }
      return h("div", { innerHTML: newStr });
    },
  },
  {
    title: renderTitle("昵称"),
    width: 200,
    key: "nickname",
  },
  {
    title: renderTitle("性别"),
    key: "gender",
    render: (row) =>
      h(
        "span",
        row["gender"] !== null
          ? row["gender"] === true
            ? "男"
            : "女"
          : "保密",
      ),
  },
  {
    title: renderTitle("注册手机号"),
    key: "phone",
  },
  {
    title: renderTitle("注册时间"),
    key: "createdAt",
  },
  {
    title: renderTitle("操作"),
    key: "action",
    render: () =>
      h(NSpace, () => [
        h(NButton, { type: "info", size: "small" }, () => "查看"),
        h(
          NButton,
          { type: "warning", size: "small", secondary: true },
          () => "加入黑名单",
        ),
      ]),
  },
];

function renderTitle(title) {
  return () => h("span", { class: "text-4 text-gray-600 font-bold" }, title);
}

const genderOptions = [
  {
    label: "全部",
    value:""
  },
  {
    label: "男",
    value: 'true',
  },
  {
    label: "女",
    value: 'false',
  },
];

const pagination = ref({
  pageSize: 8,
  page: 1,
});
</script>

<template>
  <data-form
    :get-data="getData"
    v-model:query-model="queryModel"
    :pagination="pagination"
    :columns="columns"
  >
    <template #query>
      <query-item label="用户名">
        <n-input v-model:value="queryModel.username" placeholder="输入用户名" />
      </query-item>
      <query-item label="性别">
        <n-select
            :options="genderOptions"
            class="w-[100px]"
            v-model:value="queryModel.gender"
        />
      </query-item>
    </template>
  </data-form>
</template>

<style scoped></style>
