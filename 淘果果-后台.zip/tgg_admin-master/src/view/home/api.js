import {request} from "../../utils/request.js";

export const getOrderAnalysis = (range)=>request.get("/api/order/analysis?range="+range)
export const getOrderProfitStats = (params)=>request.get("/api/order/orderProfitStats",{params})
export const getOrderPriceTotalStats = (params)=>request.get("/api/order/orderPriceTotalStats",{params})
export const getUserTotalStats = (params)=>request.get("/api/user/statsUserNumber",{params})
export const getHotSale=()=>request.get("/api/order/getHotSale")
