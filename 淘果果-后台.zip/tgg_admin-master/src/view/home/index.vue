<script setup>
import dataAnalysis from "../data-analysis/index.vue";

import {
  getHotSale,
  getOrderPriceTotalStats,
  getOrderProfitStats, getUserTotalStats,
} from "./api.js";
import DataStatsCard from "../../components/common/card/DataStatsCard.vue";
import SalesSummaryCard from "../../components/common/card/SalesSummaryCard.vue";
import { h, onMounted, ref } from "vue";

function renderRankingByIndex(index) {

  if (index <= 3) {
    return () => h("div", { class: `i-ri:trophy-fill text-6 ${_getColor()}` });
  }else {
    return ()=>h('div',{class:`text-xl ${_getColor()} font-bold text-center min-w-[25px]`},index)
  }

  function _getColor() {
    return index === 1
      ? "text-[rgb(242,212,113)]"
      : index === 2
        ? "text-[#cdcdcdff]"
        : index === 3
          ? "text-[#f2ab71ff]"
          : "text-[#515151ff]";
  }
}

const data = ref([]);

onMounted(async () => {
  data.value = (await getHotSale()).data;
});
</script>

<template>
  <div class="grid grid-cols-10 gap-5 p-6">
    <n-space vertical class="col-span-4 bg-white card rounded-xl p-4">
      <n-space>
        <n-avatar :size="64" circle src="/下载.jpg"></n-avatar>
        <n-space vertical>
          <span class="font-bold text-2xl">Admin</span>
          <n-tag type="primary" size="small">超级管理员</n-tag>
        </n-space>
      </n-space>
      <n-space vertical>
        <div>“如果我们有勇气去追求，我们所有的梦想都能实现。”</div>
        <div class="text-end text-gray-400">——沃尔特·迪斯尼</div>
      </n-space>
    </n-space>
    <data-stats-card
      class="col-span-2"
      title="本月订单总额"
      prefix="￥"
      :get-data="getOrderPriceTotalStats"
    >
      <n-avatar :size="64" class="m-4 bg-red-50">
        <div class="i-ri:shopping-cart-2-fill bg-red-400 text-4xl"></div>
      </n-avatar>
    </data-stats-card>
    <data-stats-card
      class="col-span-2"
      title="本月净利润"
      prefix="￥"
      :get-data="getOrderProfitStats"
    >
      <n-avatar :size="64" class="m-4 bg-yellow-50">
        <div class="i-ri:coins-fill bg-yellow-400 text-4xl"></div>
      </n-avatar>
    </data-stats-card>
    <data-stats-card
      class="col-span-2"
      title="用户总数"
      suffix="人"
      :get-data="getUserTotalStats"
    >
      <n-avatar :size="64" class="m-4 bg-green-50">
        <div class="i-ri:group-fill bg-green-400 text-4xl"></div>
      </n-avatar>
    </data-stats-card>
    <sales-summary-card class="col-span-8" />
    <n-space vertical class="col-span-2 bg-white card rounded-xl p-4">
      <span class="text-xl font-bold">🔥热销排行榜</span>
      <n-space
        align="center"
        justify="space-between"
        class="!gap-2 px-2"
        v-for="(item,index) in data"
      >
        <n-space justify="space-between" align="center" class="text-5 min-w-[25px]">
          <component :is="renderRankingByIndex(index+1)"/>
          <div class="text-5">{{item.name}}</div>
        </n-space>
        <div class="text-5 text-red-500">{{item.value}}</div>
      </n-space>
    </n-space>
  </div>
</template>

<style scoped></style>
