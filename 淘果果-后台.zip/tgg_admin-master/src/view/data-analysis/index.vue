<template>
  <div class="p-20 px-10 bg-white card rounded-lg">
    <div ref="mapEcharts" class="map-echart mx-a max-h-[500px]"></div>
  </div>
</template>

<script setup>
import * as echarts from "echarts";
import axios from "axios";
import { nextTick, onBeforeUnmount, onMounted, ref } from "vue";
import { request } from "../../utils/request.js";

let timer;
const mapEcharts = ref(null);
let map;

function setTimer() {
  // 当前选中区域的下标
  let curIndex = -1;
  timer && clearInterval(timer);
  timer = setInterval(() => {
    map.dispatchAction({
      type: "downplay",
      seriesIndex: 0,
      dataIndex: curIndex,
    });
    // 显示tooltip
    map.dispatchAction({
      type: "showTip",
      seriesIndex: 0,
      dataIndex: curIndex,
    });
  }, 1000);
}
function clearTimer() {
  timer && clearInterval(timer);
}

async function initMapEcharts(data) {
  // 获取地图数据
  // 将下载后的json文件放置/public目录下
  const res = await axios.get("/china.json");
  echarts.registerMap("china", res.data);
  await nextTick();
  map = echarts.init(mapEcharts.value);
  // 设置基础配置项
  const option = {
    // 标题
    title: {
      text: "用户分布",
      left: "center",
    },
    // 悬浮窗
    tooltip: {
      trigger: "item",
      formatter: function (params) {
        return `${params.name}: ${params.value || 0}`;
      },
    },
    // 图例
    visualMap: {
      min: 0,
      max: 50,
      text: ["High", "Low"],
      realtime: false,
      calculable: true,
      inRange: {
        color: ["rgb(238,238,238)", "rgb(17,92,246)"],
      },
    },
    // 要显示的散点数据
    series: [
      {
        type: "map",
        map: "china",
        top: 150,
        zoom: 1.7,
        aspectScale: 0.8,
        data: data,
        emphasis: {
          label: {
            show: true,
          },
          itemStyle: {
            areaColor: "rgb(187,173,233)", // 这里设置高亮颜色
          },
        },
      },
    ],
  };
  // 将配置应用到地图上
  map.setOption(option);
  // 设置定时器，自动循环触发tooltip悬浮窗事件
  setTimer();
  // 当鼠标在地图上时，停止自动tooltip事件
  map.on("mouseover", { series: 0 }, function (params) {
    clearTimer();
  });
  // 当鼠标移出地图后，再自动tooltip
  map.on("mouseout", { series: 0 }, function (params) {
    setTimer();
  });
}

onMounted(async () => {
  const res = await request.get("/api/user/countAddress");
  initMapEcharts(res.data);
});

onBeforeUnmount(() => {
  clearTimer();
});
</script>

<style>
.map-echart {
  height: 900px;
  width: 900px;
}
</style>
