<script setup>
import { h, onMounted, ref } from "vue";
import { getData } from "../user/list/api.js";

const columns = [
  {
    title: ()=>h("span",{class:"text-4"},"UID"),
    key: "id",
  },
  {
    title: ()=>h("span",{class:"text-4"},"用户名"),
    key: "username",
  },
  {
    title: ()=>h("span",{class:"text-4"},"昵称"),
    key: "nickname",
  },
  {
    title: ()=>h("span",{class:"text-4"},"性别"),
    key: "gender",
    render: (row) => h("span", row["gender"] ? "男" : "女"),
  },
  {
    title: ()=>h("span",{class:"text-4"},"联系电话"),
    key: "phone",
  },
  {
    title: ()=>h("span",{class:"text-4"},"注册时间"),
    key: "createdAt",
  },
];

const data = ref();
const pagination = {
  pageSize: 10,
  pageCount:100
};


onMounted(async () => {
  data.value = (await getData()).data;
});
</script>

<template>
  <n-space vertical class="p-5 m-5 card rounded-lg bg-white">
    <div class="title">
      {{$route.meta.label}}
    </div>
    <n-data-table
        remote
        striped
        :pagination="pagination"
        ref="table"
        :columns="columns"
        :data="data"
    />
  </n-space>


  <!--  <n-data-table-->
  <!--      remote-->
  <!--      ref="table"-->
  <!--      :columns="columns"-->
  <!--      :data="data"-->
  <!--      :loading="loading"-->
  <!--      :pagination="pagination"-->
  <!--      :row-key="rowKey"-->
  <!--      @update:page="handlePageChange"-->
  <!--  />-->
</template>

<style scoped>
.title {
  font-size: 23px;
  position: relative;
}

.title:after {
  content: "";
  position: absolute;
  top: 10%;
  left: -10px;
  height: 80%;
  width: 4px;
  background-color: #2e921b;
}
</style>
