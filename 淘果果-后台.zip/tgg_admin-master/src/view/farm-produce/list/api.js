import { request } from "../../../utils/request.js";

export const getData = async (data) => request.post("/api/produce/page", data);
export const getById = async (id) => request.get("/api/produce/" + id);
export const deleteProduce = async (id) =>
  request.delete("/api/produce", { params: { id } });
export const add = async (data) => request.post("/api/produce", data);
export const update = async (data) => request.put("/api/produce", data);
