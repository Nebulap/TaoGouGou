<script setup>
import { ref } from "vue";

const props = defineProps({
  title: {
    type: String,
  },
  data: {
    type: Object,
  },
  updateData: {
    type: Function,
  },
  addData: {
    type: Function,
  },
  refreshData:{
    type:Function
  }
});

const show = ref(false);
const active = ref("view")

const emit = defineEmits(["updateData", "addData"]);

function closeModal() {
  show.value = false;
}

function openModal(newActive) {
  active.value = newActive
  show.value = true;
}

async function onConfirm() {
  let res = {
    code: 100,
  };
  if (active.value === "edit") {
    res = (await props.updateData(props.data));
  } else if (active.value === "add") {
    res = (await props.addData(props.data));
  }
  if (res.code !== 100 && active.value !== 'view') {
    $message.warning(res["msg"]);
  }else if (active.value !== "view"){
    $message.success("操作成功")
    closeModal()
    props.refreshData()
  }
}

defineExpose({
  closeModal,
  openModal,
});
</script>

<template>
  <n-modal v-model:show="show" mask-closable closable>
    <n-space
      vertical
      class="bg-white p-5 min-w-[600px] rounded-xl shadow-white shadow-sm"
    >
      <div class="text-2xl font-bold mb-3">{{ title ?? "编辑" }}</div>
      <slot  :active="active"/>
      <n-space justify="end" align="center">
        <n-button type="default" secondary @click="closeModal">取消</n-button>
        <n-button type="info" @click="onConfirm">确定</n-button>
      </n-space>
    </n-space>
  </n-modal>
</template>

<style scoped></style>
