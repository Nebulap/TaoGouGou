<script setup>
import DataForm from "../../../components/common/data-form/DataForm.vue";

import { add, deleteProduce, getById, getData, update } from "./api.js";
import { h, onBeforeMount, ref } from "vue";
import { NButton, NEllipsis, NPopconfirm, NSpace, NTag } from "naive-ui";
import ProduceForm from "./model/ProduceForm.vue";
import { formatTimestamp } from "../../../utils/index.js";
import QueryItem from "../../../components/common/data-form/QueryItem.vue";

const dataForm = ref();
const imgList = ref([]);
const queryModel = ref({
  product: "",
  customerId: "",
  customStringQueryItems: [
    {
      name: "category",
      comparison: "EQ",
      value: "",
    },
    {
      name: "productName",
      comparison: "LIKE",
      value: "",
    },
  ],
});

const renderQuantity = (quantity) => {
  return quantity >= 200
    ? "text-green-500"
    : quantity >= 100
      ? "text-yellow-500"
      : "text-red-500";
};

const columns = [
  {
    title: renderTitle("#"),
    width: 70,
    key: "id",
  },
  {
    title: renderTitle("产品名称"),
    width: 210,
    key: "productName",
    render: (row) => {
      let newStr = row["productName"];
      if (queryModel.value["productName"] !== "") {
        newStr = row["productName"].replace(
          queryModel.value["productName"],
          `<span class='text-red-500'>${queryModel.value["productName"]}</span>`,
        );
      }
      return h("div", { innerHTML: newStr });
    },
  },
  {
    title: renderTitle("分类"),
    width: 110,
    key: "category",
  },
  {
    title: renderTitle("进价(/kg)"),
    width: 110,
    key: "price",
    render: (row) => `¥${row["purchasePrice"].toFixed(2)}`,
  },
  {
    title: renderTitle("售价(/kg)"),
    width: 110,
    key: "price",
    render: (row) => `¥${row["price"].toFixed(2)}`,
  },
  {
    title: renderTitle("库存(kg)"),
    width: 120,
    key: "quantity",
    render: (row) =>
      h("span", { class: renderQuantity(row["quantity"]) }, row["quantity"]),
  },
  {
    title: renderTitle("农场位置"),
    width: 260,
    key: "farmLocation",
  },
  {
    title: renderTitle("收获日期"),
    width: 150,
    key: "harvestDate",
    render: (row) => formatTimestamp(row["harvestDate"]),
  },
  {
    title: renderTitle("保质期(天)"),
    width: 150,
    key: "shelfLifeDays",
  },
  {
    title: renderTitle("有机"),
    width: 120,
    key: "organic",
    render: (row) => (row["organic"] ? "是" : "否"),
  },
  {
    title: renderTitle("操作"),
    key: "action",
    render: (row) =>
      h(NSpace, () => {
        return [
          h(
            NButton,
            {
              type: "info",
              size: "small",
              onClick: () => showForm("edit", row["id"]),
            },
            () => "编辑",
          ),
          h(
            NPopconfirm,
            {
              onPositiveClick: () => deleteHandler(row["id"]),
            },
            {
              default: () => "此操作不可撤销!",
              trigger: () =>
                h(
                  NButton,
                  {
                    type: "error",
                    size: "small",
                    secondary: true,
                  },
                  () => "删除",
                ),
            },
          ),
        ];
      }),
  },
];

function renderTitle(title) {
  return () => h("span", { class: "text-4 text-gray-600 font-bold" }, title);
}

const pagination = ref({
  pageSize: 8,
  page: 1,
});

const typeOptions = [
  {
    label: "水果",
    value: "水果",
  },
  {
    label: "蔬菜",
    value: "蔬菜",
  },
  {
    label: "酒类",
    value: "酒类",
  },
  {
    label: "肉类",
    value: "肉类",
  },
  {
    label: "其他",
    value: "其他",
  },
];

const data = ref({
  harvestDate: 0,
});

const formRef = ref();

function fileFinish({ event }) {
  data.value["img"] = event.target.response;
}

function createFileInfo(url) {
  return {
    id: new Date().getTime(),
    name: "",
    status: "finished",
    thumbnailUrl: url,
  };
}

async function showForm(active, id = 0) {
  imgList.value = [];
  if (active === "edit") {
    data.value = (await getById(id)).data;
    data.value["harvestDate"] = new Date(data.value["harvestDate"]).getTime();
    if (data.value["img"]) {
      imgList.value.push(createFileInfo(data.value["img"]));
    }
  } else if (active === "add") {
    data.value = {};
  }

  if (formRef.value) {
    formRef.value.openModal(active);
  }
}

async function deleteHandler(id) {
  await deleteProduce(id);
  $message.success("删除成功");
  refreshData();
}

function refreshData() {
  if (dataForm.value) {
    dataForm.value.refreshData();
  }
}
</script>

<template>
  <produce-form
    :data="data"
    :add-data="add"
    :update-data="update"
    :refresh-data="refreshData"
    active="add"
    ref="formRef"
    v-slot="slotProps"
  >
    <n-form label-align="right" :label-placement="'left'" :label-width="80">
      <n-form-item
        label="ID"
        v-if="['edit', 'view'].includes(slotProps.active)"
      >
        <n-input-number
          placeholder="id"
          disabled
          :show-button="false"
          v-model:value="data['id']"
        />
      </n-form-item>
      <n-form-item label="产品图像">
        <n-upload
          action="/api/file/img"
          :default-file-list="imgList"
          method="put"
          @finish="fileFinish"
          list-type="image-card"
          :max="1"
        >
          点击上传
        </n-upload>
      </n-form-item>
      <n-form-item label="产品名称">
        <n-input
          placeholder="请输入产品名称"
          :show-button="false"
          v-model:value="data['productName']"
        />
      </n-form-item>
      <n-form-item label="分类">
        <n-select
          placeholder="请选择分类"
          v-model:value="data['category']"
          :options="typeOptions"
        ></n-select>
      </n-form-item>
      <div class="grid grid-cols-2">
        <n-form-item label="进价">
          <n-input-number
            placeholder="请输入进价"
            :show-button="false"
            v-model:value="data['purchasePrice']"
          >
            <template #suffix> ¥/kg</template>
          </n-input-number>
        </n-form-item>
        <n-form-item label="库存">
          <n-input-number
            placeholder="请输入库存"
            :show-button="false"
            v-model:value="data['quantity']"
          >
            <template #suffix> kg</template>
          </n-input-number>
        </n-form-item>
      </div>
      <div class="grid grid-cols-2">
        <n-form-item label="售价">
          <n-input-number
            placeholder="请输入售价"
            :show-button="false"
            v-model:value="data['price']"
          >
            <template #suffix> ¥/kg</template>
          </n-input-number>
        </n-form-item>
        <n-form-item label="保质期">
          <n-input-number
            placeholder="请输入保质期"
            :show-button="false"
            v-model:value="data['shelfLifeDays']"
          >
            <template #suffix> 天</template>
          </n-input-number>
        </n-form-item>
      </div>
      <n-form-item label="有机">
        <n-switch v-model:value="data['organic']"></n-switch>
      </n-form-item>
      <n-form-item label="收获日期">
        <n-date-picker
          v-model:value="data['harvestDate']"
          value-format="yyyy-MM-dd"
          placeholder="选择收获日期"
          type="date"
        />
      </n-form-item>
      <n-form-item label="农场位置">
        <n-input
          placeholder="请输入农场位置"
          :show-button="false"
          v-model:value="data['farmLocation']"
        />
      </n-form-item>
    </n-form>
  </produce-form>
  <data-form
    ref="dataForm"
    :get-data="getData"
    v-model:query-model="queryModel"
    :pagination="pagination"
    :columns="columns"
  >
    <template #active>
      <n-button
        type="info"
        secondary
        class="px-5"
        @click="() => showForm('add')"
      >
        添加
      </n-button>
    </template>
    <template #query>
      <query-item label="名称">
        <n-input
          v-model:value="queryModel.customStringQueryItems[1].value"
          placeholder="输入产品名称"
        />
      </query-item>
      <query-item label="产品类型">
        <n-select
          class="w-[120px]"
          default-value="所有"
          v-model:value="queryModel.customStringQueryItems[0].value"
          :options="[
            {
              label: '所有',
              value: '',
            },
            ...typeOptions,
          ]"
        >
        </n-select>
      </query-item>
    </template>
  </data-form>
</template>

<style scoped></style>
