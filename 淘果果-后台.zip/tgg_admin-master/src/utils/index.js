import { createDiscreteApi } from "naive-ui";

export const { message } = createDiscreteApi(["message"]);

export function formatTimestamp(timestamp){
    const date = new Date(timestamp)
    return `${date.getFullYear()}-${date.getMonth()+1}-${date.getDate()}`
}

window.$message = message
