import axios from "axios";
import { message } from "./index.js";
// import {message} from "./index.js";

const request = axios.create({
  // baseURL:"/api",
  timeout: 5000,
});

function onFulfilled(res) {
  switch (res.data.code) {
    case 503:
      message.error("服务未启动,请联系网站管理员"+res.data['msg']);
      break
    case 100:
      return res.data
    default:
      message.warning(res.data['msg'])
  }
  return res.data;
}
function onRejected(error) {
  console.error(error)
}

request.interceptors.response.use(onFulfilled, onRejected);
export { request };
