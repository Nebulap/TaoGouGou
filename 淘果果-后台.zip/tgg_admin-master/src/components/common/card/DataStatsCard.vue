<script setup>
import { onMounted, ref } from "vue";

const props = defineProps({
  getData: {
    type: Function,
  },
  title: {
    type: String,
  },
  prefix: {
    type: String,
  },
  suffix: {
    type: String,
  },
});

const data = ref({
  total: 0,
  difference: 0,
});

const month = new Date().getMonth() + 1; //1
const statsParams = {
  comparedMonth: month - 1 === 0 ? 12 : month - 1,
  month: month,
};

onMounted(async () => {
  data.value = (await props.getData(statsParams)).data;
});
</script>

<template>
  <n-space
    vertical
    justify="space-between"
    class="bg-[rgb(255,255,255)] rounded-xl card"
  >
    <n-space justify="space-between">
      <n-space vertical class="p-3">
        <span class="text-[17px] font-bold">{{ title }}</span>
        <span class="text-2xl font-bold">
          {{ prefix }}
          <n-number-animation
            show-separator
            :from="0"
            :to="data.total"
            active
          />
          {{ suffix }}
        </span>
      </n-space>
      <slot />
    </n-space>
    <n-space
      justify="space-between"
      class="p-3 py-4 bg-[rgb(246,248,252)] rounded-b-xl"
    >
      <div
        v-if="data.difference >= 0"
        class="flex items-center text-green-5 font-bold"
      >
        <div class="i-ri:arrow-up-line"></div>
        {{ Math.abs(data.difference) }}%
        <span class="m-l-2 text-gray-4">上月</span>
      </div>
      <div v-else class="flex items-center text-red-5 font-bold">
        <div class="i-ri:arrow-down-line"></div>
        {{ Math.abs(data.difference) }}%
      </div>
      <span class="text-gray-6 font-bold">查看更多</span>
    </n-space>
  </n-space>
</template>

<style scoped></style>
