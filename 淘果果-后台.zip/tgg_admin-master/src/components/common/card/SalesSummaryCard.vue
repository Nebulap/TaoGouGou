<script setup>

import {h, onMounted} from "vue";
import * as echarts from "echarts";
import {getOrderAnalysis} from "../../../view/home/api.js";

const rangeSelectOptions = [
  {
    label: () => h("span", { class: "text-gray-800 font-bold" }, "最近30天"),
    value: "LAST_30_DAYS",
  },
  {
    label: () => h("span", { class: "text-gray-800 font-bold" }, "最近7天"),
    value: "LAST_7_DAYS",
  },
];

let myChart;

async function initChart() {
  const chartDom = document.getElementById("sales-chart");
  myChart = echarts.init(chartDom);
  await updateChart("LAST_30_DAYS");
}

async function updateChart(value) {
  const data = (await getOrderAnalysis(value)).data;
  const date = data.map((item) => item.date.slice(5));
  const hideProfit = data.map((item) => item.hideProfit);
  const profit = data.map((item) => item.profit);
  const total = data.map((item) => item.total - item.profit);

  const option = {
    color: ["rgb(17,92,246)", "rgb(173,233,233)", "rgb(241,245,248)"],
    tooltip: {
      trigger: "axis",
      axisPointer: {
        type: "shadow",
      },
      formatter: function (params) {
        const date = params[0].name;
        return `<div>
                        <div>${date}</div>
                        <div>${params[2].seriesName}: ￥${params[1].value + params[2].value}</div>
                        <div>${params[1].seriesName}: ￥${params[1].value}</div>
                        <div>${params[0].seriesName}: ￥${params[0].value}</div>
                    </div>`
      },
    },
    legend: {
      data: [
        { icon: "circle", name: "总收入" },
        { icon: "circle", name: "净利润" },
        { icon: "circle", name: "潜在利润" },
      ],
      top: 5,
      left: 20,
    },
    xAxis: {
      type: "category",
      data: date,
    },
    yAxis: {
      type: "value",
    },
    series: [
      {
        name: "潜在利润",
        type: "bar",
        stack: "dd",
        data: hideProfit,
      },
      {
        name: "净利润",
        type: "bar",
        stack: "dd",
        data: profit,
      },
      {
        name: "总收入",
        type: "bar",
        stack: "dd",
        data: total,
      },
    ],
  };

  option && myChart.setOption(option);
}

onMounted( () => {
  initChart();
});
</script>

<template>
  <div class="p-4 px-0 card rounded-lg bg-white">
    <div class="flex justify-between px-6">
      <span class="font-bold text-5">销售汇总</span>
      <n-select
          @update-value="updateChart"
          default-value="LAST_30_DAYS"
          :options="rangeSelectOptions"
          class="max-w-[120px] !rounded"
      >
      </n-select>
    </div>
    <div id="sales-chart" class="w-full h-[400px]"></div>
  </div>

</template>

<style scoped>

</style>
