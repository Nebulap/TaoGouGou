<script setup>

defineProps({
  label:{
    type:String
  }
})
</script>

<template>
  <n-space justify="center" align="center" class="mx-4 my-2 !gap-2">
    <span class="text-gray-700 font-bold">
      {{label}}:
    </span>
    <slot />
  </n-space>
</template>

<style scoped></style>
