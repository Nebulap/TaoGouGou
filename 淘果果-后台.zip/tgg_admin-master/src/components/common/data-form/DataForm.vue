<script setup>
import { computed, onMounted, ref } from "vue";
import { NButton, NSpace } from "naive-ui";
import { message } from "../../../utils/index.js";

const emit = defineEmits(["update:queryModel"]);
const props = defineProps({
  getData: {
    type: Function,
  },
  queryModel: {
    type: Object,
  },
  columns: {
    type: Array,
  },
  pagination: {
    type: Object,
  },
});

const data = ref();

const { pagination, columns, getData } = props;

//pageSize 初始分页大小
const initPagination = computed(() => ({
  pageNum: 0,
  pageSize: pagination.pageSize,
}));

function resetPagination() {
  pagination.page = 1;
}

async function query(paginationParams = null, params = null) {
  try {
    loading.value = true;
    const res = (await getData({ ...paginationParams, ...params })).data;
    data.value = res["pageData"];
    pagination.pageCount = res["totalPages"];

    if (res["pageData"].length === 0 && paginationParams.pageNum > 0) {
      await query(
        {
          ...paginationParams,
          pageNum: paginationParams.pageNum - 1,
        },
        params,
      );
      pagination.page = paginationParams.pageNum;
    }
  } finally {
    loading.value = false;
  }
}

const loading = ref(false);

async function handlePageChange(currentPage) {
  pagination.page = currentPage;
  await query(
    {
      pageNum: currentPage - 1,
      pageSize: pagination.pageSize,
    },
    props.queryModel,
  );
}

/**
 * 重置查询条件模型和分页,并查询
 * @returns {Promise<void>}
 */
async function refresh() {
  const initQueryModel = resetModel(
    JSON.parse(JSON.stringify(props.queryModel)),
  );
  console.log(initQueryModel);
  emit("update:queryModel", initQueryModel);
  await query(initPagination.value, null);
  resetPagination();
}

function resetModel(model) {
  if (typeof model === "string") return "";
  if (typeof model === "number") return 0;
  for (let key in model) {
    if (Object.prototype.hasOwnProperty.call(model, key)) {
      if (typeof model[key] === "string") {
        model[key] = "";
      }
      if (typeof model[key] === "number") {
        model[key] = 0;
      }
      if (Array.isArray(model[key])) {
        model[key] = model[key].map((item) => ({
          name: item["name"],
          comparison: item["comparison"],
          value: resetModel(item["value"]),
        }));
      }
    }
  }
  return model;
}

async function refreshData() {
  await query(
    {
      pageNum: pagination.page - 1,
      pageSize: pagination.pageSize,
    },
    props.queryModel,
  );
}

async function search() {
  await query(initPagination.value, props.queryModel);
  resetPagination();
  message.success("搜索完成");
}

onMounted(async () => {
  await query({
    pageNum: 0,
    pageSize: pagination.pageSize,
  });
});

defineExpose({
  refreshData,
});
</script>

<template>
  <n-space vertical class="!gap-0">
    <n-space vertical class="p-5 m-5 mb-0 card rounded-lg bg-white">
      <n-space align="center" @keydown.enter="search">
        <slot name="query" />
        <n-space justify="end" class="self-end">
          <n-button type="default" secondary class="self-end" @click="refresh">
            <template #icon>
              <div class="i-ri:loop-right-fill"></div>
            </template>
            重置
          </n-button>
          <n-button type="info" class="self-end" @click="search">
            <template #icon>
              <div class="i-ri:search-line"></div>
            </template>
            搜索
          </n-button>
        </n-space>
      </n-space>
    </n-space>

    <n-space vertical class="p-5 m-5 card rounded-lg bg-white">
      <n-space justify="space-between" align="center">
        <div class="title">
          {{ $route.meta.label }}
        </div>
        <slot name="active"></slot>
      </n-space>

      <n-data-table
        remote
        striped
        :pagination="pagination"
        ref="table"
        :columns="columns"
        :data="data"
        :loading="loading"
        @update:page="handlePageChange"
      />
    </n-space>
  </n-space>
</template>

<style scoped>
.title {
  font-size: 23px;
  position: relative;
}

.title:after {
  content: "";
  position: absolute;
  top: 10%;
  left: -10px;
  height: 80%;
  width: 4px;
  background-color: #2e921b;
}
</style>
