<script setup>
import { toRefs } from "vue";
import { useTabStore } from "../../store/useTabStore.js";

const { handleClose, addTab, selectTab } = useTabStore();
const { tabs, currentTab } = toRefs(useTabStore().state);
</script>

<template>
  <n-tabs
      class="bg-white"
      style="border: none"
    v-model:value="currentTab"
    size="small"
    type="card"
    closable
    tab-style="min-width: 80px;"
    tab-class="!bg-[rgb(241,243,247)] !rounded-t-lg"
    @close="handleClose"
  >
    <n-tab
      v-for="tab in tabs"
      :key="tab"
      :tab="tab.label"
      :name="tab.name"
      class="!border-none"
      @click="()=>selectTab(tab.name)"
    >
    </n-tab>
  </n-tabs>
</template>

<style scoped>
</style>
