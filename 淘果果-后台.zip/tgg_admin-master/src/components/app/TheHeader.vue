<script setup>
import { useRoute } from "vue-router";

const route = useRoute();
</script>

<template>
  <div class="grid grid-cols-3 items-center p-2 pb-4 px-5 bg-white">
    <!--    标题和描述-->
    <div class="col-span-1 flex flex-col">
      <div class="font-bold text-2xl">
        {{ $route.meta.label }}
      </div>
      <span class="text-gray-500">{{ $route.meta.description }}</span>
    </div>
    <!--    搜索-->
    <div class="grid-col-span-1">
      <n-input placeholder="搜索一些东西......" class="p-1">
        <template #prefix>
          <div class="i-ri:search-line text-2xl text-gray-400 font-bold"></div>
        </template>
      </n-input>
    </div>
    <!--    头像-->
    <div class="grid-col-span-1">3</div>
  </div>
<!--  <n-float-button class="bottom-40 right-50 !absolute">-->
<!--    <div class="i-ri:settings-5-line text-3xl"></div>-->
<!--  </n-float-button>-->
</template>

<style scoped></style>
