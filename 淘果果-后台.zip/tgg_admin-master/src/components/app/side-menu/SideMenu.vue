<script setup>
import { NMenu } from "naive-ui";
import {computed, h, nextTick, onMounted, ref} from "vue";
import { useRoute, useRouter } from "vue-router";
import SideMenuItem from "./model/SideMenuItem.vue";
import {useTabStore} from "../../../store/useTabStore.js";

const router = useRouter();
const route = useRoute();
const tabStore = useTabStore()
const menuRef = ref(null);

const menuOptions = computed(() => {
  return _builderMenu(router.options.routes);

  function _builderMenu(routes) {
    return routes.map((item) => {
      const option = {
        key: item.name,
        icon: () => _renderIcon(item.meta.icon),
      };

      if (item.children) {
        option["label"] = () => h("span", item.meta.label);
        option["children"] = _builderMenu(item.children);
      } else {
        option["label"] = () => _renderLabel(item);
      }
      return option;
    });
  }

  function _renderLabel(item) {
    return h(SideMenuItem, {
      path: item.path,
      name: item.name,
      label: item.meta.label,
    });
  }

  function _renderIcon(iconName) {
    return h("div", { class: iconName });
  }
});

const selected = computed(() => route.name + "");

onMounted(async ()=>{
  await nextTick()
  tabStore.setSideMenuRef(menuRef)
})
</script>

<template>
  <n-menu
      accordion
    ref="menuRef"
    :collapsed-width="64"
    :collapsed-icon-size="22"
    :options="menuOptions"
    :value="selected"
    class="select-none"
  />
</template>

<style scoped></style>
