<script setup>
import { useTabStore } from "../../../../store/useTabStore.js";

defineProps({
  path: {
    type: String,
  },
  name: {
    type: String,
  },
  label: {
    type: String,
  },
});

const { addTab } = useTabStore();
</script>

<template>
  <RouterLink :to="{ path }" @click="() => addTab({ name, label })">
    {{ label }}
  </RouterLink>
</template>

<style scoped></style>
