


console.log(["a","b"].includes("a"))
